# Testing Guide

Convert Plus uses **PHPStan** for static analysis and maintains a stub file for PHPUnit-compatible testing infrastructure.

## Static Analysis: PHPStan

### Configuration

**File:** `phpstan.neon`

| Setting | Value |
|---------|-------|
| Level | 9 (maximum strictness) |
| Analysed paths | `framework/classes`, `framework/functions`, `convertplug.php`, `modules/`, `classes/`, `admin/`, `lang/` |
| WordPress stubs | `vendor/php-stubs/wordpress-stubs/wordpress-stubs.php` |
| Plugin stubs | `tests/php/stubs/convertplug-stubs.php` |
| Extension | `szepeviktor/phpstan-wordpress` |
| Baseline | `phpstan-baseline.neon` |

### Running PHPStan

```bash
# Install dependencies first
composer update --classmap-authoritative

# Run analysis
composer run phpstan

# Or directly:
vendor/bin/phpstan --memory-limit=-1 analyse
```

### PHPStan Baseline

`phpstan-baseline.neon` contains temporarily suppressed errors. The goal is to reduce this file to zero over time. When fixing issues, remove the corresponding entries from the baseline rather than adding new suppressions.

### Regenerating Stubs

The plugin stubs at `tests/php/stubs/convertplug-stubs.php` are used to give PHPStan type information about the plugin's own classes when analysing code that references them.

To regenerate:

```bash
composer run gen-stubs
```

This runs the stubs generator against a built artifact in `artifact/phpstan/convertplug/` and outputs to `tests/php/stubs/convertplug-stubs.php`. The artifact directory is cleaned up automatically.

## Code Style: PHPCS/WPCS

### Configuration

**File:** `phpcs.xml.dist`

Rulesets applied:
- `PHPCompatibility` — PHP 5.3+
- `WordPress-Core` — WordPress coding standards
- `WordPress-Docs` — PHPDoc requirements
- `WordPress-Extra` — Additional WP best practices

### Running PHPCS

```bash
# Check for violations
composer run lint

# Auto-fix fixable violations
composer run format
```

### What is Excluded

The PHPCS ruleset excludes:
- `node_modules/`, `vendor/`, `lib/`
- `framework/` (internal framework, different standards)
- `admin/bsf-core/`, `admin/bsf-analytics/` (third-party BSF libraries)
- `stubs-generator.php`
- Specific theme template files with intentional legacy code

## JavaScript Linting

```bash
# Lint JS
npm run lint:js

# Lint CSS
npm run lint:css
```

Uses `@wordpress/scripts` ESLint and `@wordpress/stylelint-config`.

## Manual Testing Checklist

When making changes, manually verify:

### Module Functionality
- [ ] Modal Popup displays correctly and triggers fire as configured
- [ ] Slide-In Popup animation works
- [ ] Info Bar sticks to the page correctly
- [ ] Forms submit successfully and subscribers are saved
- [ ] Analytics impressions and conversions increment

### Admin UI
- [ ] Campaign creation wizard completes both steps
- [ ] Style customizer saves settings
- [ ] Analytics charts render correctly
- [ ] Export CSV downloads with correct data
- [ ] Import ZIP restores styles correctly

### Security
- [ ] All admin AJAX actions verify nonces
- [ ] Form submissions verify `cp-submit-form-{style_id}` nonce
- [ ] User capability `access_cp` is checked on admin pages
- [ ] No unescaped output in views

## PHP Version Compatibility

The plugin is tested for compatibility with PHP 5.3+. PHPCompatibility sniffs enforce this. All code in `admin/`, `modules/`, `classes/`, and `framework/` must be compatible with PHP 5.3.

> Note: PHP 5.3 reached end-of-life in 2014. For new code, target PHP 7.4+ while maintaining compatibility with the declared minimum.

## WordPress Version Compatibility

Minimum WordPress: 3.5. The plugin is actively tested against the latest WordPress release. The `phpstan-wordpress` extension and `wordpress-stubs` package provide type information for the WordPress version targeted in `phpstan.neon`.

## Related Pages

- [Build Tooling](Build-Tooling)
- [Contributing Guide](Contributing-Guide)
- [Troubleshooting FAQ](Troubleshooting-FAQ)
