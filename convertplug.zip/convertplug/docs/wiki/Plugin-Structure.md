# Plugin Structure

## Directory Layout

```
convertplug/
├── convertplug.php                  ← Plugin entry point (headers, constants, bootstrap)
├── index.php                        ← Directory access guard
├── changelog.txt                    ← Version history
├── package.json                     ← npm config (Grunt build, linting, i18n)
├── composer.json                    ← Composer config (dev tools: WPCS, PHPStan)
├── phpcs.xml.dist                   ← PHPCS/WPCS ruleset
├── phpstan.neon                     ← PHPStan config (level 9)
├── phpstan-baseline.neon            ← Temporary PHPStan error suppressions
├── Gruntfile.js                     ← Root Grunt task runner
│
├── admin/                           ← Admin UI and backend logic
│   ├── admin.php                    ← Admin page router (views dispatched by ?page= param)
│   ├── ajax-actions.php             ← All wp_ajax_* handlers and admin_post_* handlers
│   ├── settings.php                 ← Settings page view
│   ├── debug.php                    ← Debug panel view
│   ├── get-started.php              ← Welcome/Get Started page view
│   ├── modules.php                  ← Module enable/disable view
│   ├── knowledge-base.php           ← Knowledge base page
│   ├── resources.php                ← Resources page
│   ├── import-ajax.php              ← Import handler
│   ├── assets/                      ← Admin CSS and JS assets
│   ├── bsf-analytics/               ← BSF Analytics library (usage opt-in)
│   ├── bsf-core/                    ← BSF license manager, auto-updater
│   ├── contacts/                    ← Contacts and campaign manager
│   │   ├── admin.php                ← Contacts page router
│   │   ├── views/                   ← dashboard, new-list, contacts, analytics, contact-details
│   │   ├── js/                      ← Contacts-specific scripts
│   │   └── css/                     ← Contacts-specific styles
│   └── images/                      ← Plugin logo and admin images
│
├── classes/                         ← Core plugin classes
│   ├── class-convert-plug.php       ← Main plugin class (extends Smile_Framework)
│   ├── class-convert-plug-filesystem.php
│   └── class-convert-plug-maxmind-geolocation.php
│
├── framework/                       ← Smile Framework (custom options/style system)
│   ├── class-smile-framework.php    ← Base framework class
│   ├── class-add-convertplug-widget.php
│   ├── class-cp-geolite-integration-target.php
│   ├── class-cp-geolocation-target.php
│   ├── class-cplus-ultimate-google-font-manager.php
│   ├── google-recaptcha-manager.php
│   ├── maxmind-database-manager.php
│   ├── assets/                      ← Framework JS/CSS (customizer, helper)
│   ├── classes/
│   │   ├── class-smile-framework-mapper.php   ← Input type registry
│   │   ├── class.style-framework.php          ← Style/campaign data manager
│   │   └── class-cpimport.php                 ← Import handler class
│   ├── functions/
│   │   ├── functions.php            ← Admin utility functions
│   │   ├── functions.admin.php
│   │   ├── component-count-down.php
│   │   ├── component-multi-form.php
│   │   └── component-social-media.php
│   └── lib/
│       └── fields/                  ← Field type definitions (loaded dynamically)
│
├── modules/                         ← Conversion modules
│   ├── config.php                   ← Registers and loads enabled modules
│   ├── modules-functions.php        ← Shared module utility functions (mailer, form fields)
│   ├── assets/                      ← Shared module assets
│   ├── modal/                       ← Modal Popup module
│   │   ├── class-smile-modals.php
│   │   ├── functions/               ← Modal-specific logic
│   │   ├── views/                   ← edit.php, main.php, new-style.php, analytics.php, variant/
│   │   ├── themes/                  ← Pre-built modal themes
│   │   └── presets/                 ← Preset templates
│   ├── slide_in/                    ← Slide-In Popup module
│   │   ├── class-smile-slide-ins.php
│   │   ├── functions/
│   │   ├── views/
│   │   ├── themes/
│   │   └── presets/
│   └── info_bar/                    ← Info Bar module
│       ├── class-smile-info-bars.php
│       ├── functions/
│       ├── views/
│       ├── themes/
│       └── presets/
│
├── lib/                             ← Third-party / shared libraries
│   ├── astra-notices/               ← Astra Notices library
│   ├── nps-survey/                  ← NPS Survey library
│   └── class-convertplug-nps-survey.php
│
├── lang/                            ← Translation files (.pot, .po, .mo, .json)
├── languages/                       ← Additional language files
├── tests/                           ← Test suite
│   └── php/
│       └── stubs/
│           └── convertplug-stubs.php   ← PHPStan stubs
└── vendor/                          ← Composer dev dependencies (WPCS, PHPStan, etc.)
```

## Entry Point: `convertplug.php`

This file:
1. Defines all plugin constants (see [Environment Configuration](Environment-Configuration))
2. Registers the activation hook (`on_cp_activate`)
3. Runs upgrade routines when version changes
4. Bootstraps the main `Convert_Plug` class
5. Loads admin-only classes (Google Fonts, MaxMind, Filesystem)
6. Initialises BSF Analytics

## Constants Defined

| Constant | Value |
|----------|-------|
| `CP_VERSION` | `3.6.2` |
| `CP_BASE_DIR` | Absolute filesystem path to plugin root |
| `CP_BASE_URL` | Absolute URL to plugin root |
| `CP_PLUGIN_URL` | Same as `CP_BASE_URL` (via `plugins_url`) |
| `__CP_ROOT__` | `dirname(__FILE__)` of main plugin file |
| `CP_DIR_NAME` | Plugin basename directory |
| `CP_DIR_FILE_NAME` | Plugin basename file |
| `CP_PLUS_NAME` | `Convert Plus` |
| `CP_PLUS_SLUG` | `convert-plus` |
| `SMILE_FRAMEWORK_DIR` | Absolute path to `framework/` |
| `SMILE_FRAMEWORK_URI` | URL to `framework/` |

## Related Pages

- [Architecture Overview](Architecture-Overview)
- [Smile Framework](Smile-Framework)
- [Environment Configuration](Environment-Configuration)
