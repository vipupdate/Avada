# Changelog

## Version 3.6.2 — June 18, 2025
- Improvement: Optimized codebase and improved code quality.

## Version 3.6.1 — April 23, 2025
- Fix: Resolved the issue for function `_load_textdomain_just_in_time` was called incorrectly in WP 6.8.

## Version 3.6.0 — March 18, 2025
- Security: Addressed a security bug. Please update to this version immediately.
- New: Added NPS Survey to gather user feedback.
- Improvement: Improved accessibility compliance throughout the plugin.

## Version 3.5.31 — February 03, 2025
- Security: Addressed a security bug. Props to Wordfence and Lucio Sá for responsible disclosure.
- Fix: Resolved modules showing up on the Elementor Editor screen.

## Version 3.5.30 — January 15, 2025
- Fix: Resolved Display inline and display widget issue.
- Fix: UI distortion issue fixed for Social Media Bar in Slide In Module.
- Fix: URL prefix issue — `http://` gets added after every page refresh.

## Version 3.5.29 — November 14, 2024
- Improvement: Improved code quality syntax and security checks.
- Fix: Resolved PHP deprecated errors.

## Version 3.5.28 — October 2, 2024
- Improvement: Compatibility with WordPress 6.6.
- Fix: Country names containing spaces were not being saved correctly in the select country option.
- Fix: Improved codebase for security.
- Fix: Google reCAPTCHA showing error for site key.
- Fix: Lint CSS and JS errors.
- Fix: Undefined function causing fatal error.

## Version 3.5.27 — May 16, 2024
- Fix: Improved security.
- Fix: Resolved WordPress deprecation errors.
- Fix: PHP errors and warnings.

## Version 3.5.26 — May 1, 2024
- Improvement: Compatibility with WordPress 6.5.
- Fix: License activation issue.
- Security: Addressed a security bug. Props to Wordfence.
- Fix: PHP Deprecated warning for `version_compare()`.
- Fix: PHP Deprecated warning for dynamic property creation.

## Version 3.5.25 — April 4, 2024
- Improvement: Compatibility with WordPress 6.5.
- Improvement: Compatibility with PHP 8.1.
- Fix: Fatal error while importing templates.
- Fix: Video does not display at the frontend.
- Fix: Warning displayed in the footer on mobile devices.

## Version 3.5.24 — September 20, 2021
- Improvement: Optimized database calls on Modules Dashboard.
- Improvement: Frontend mailer JS code load optimization.
- Fix: Importing templates not working while creating a module.
- Fix: String changes for Slide-in image option in customizer.
- Fix: Uncaught SyntaxError: Identifier 'getCookie' already declared.

> For the full changelog history, see `changelog.txt` in the plugin root.

## Related Pages

- [Getting Started](Getting-Started)
- [Contributing Guide](Contributing-Guide)
