# Getting Started

## What is Convert Plus?

Convert Plus is a WordPress plugin by Brainstorm Force that converts website visitors into leads. It provides three types of conversion elements:

- **Modal Popup** — lightbox overlay displayed based on configurable triggers
- **Slide-In Popup** — animated panel that slides in from a corner of the screen
- **Info Bar** — a sticky notification bar anchored to the top or bottom of the page

All three support email opt-in forms, click-through buttons, countdown timers, and social media elements.

## Requirements

| Requirement | Minimum |
|-------------|---------|
| WordPress | 3.5 |
| PHP | 5.3.2 |

## Installation

### From a ZIP file

1. Download the plugin ZIP from CodeCanyon or your Brainstorm Force account
2. Go to **WP Admin > Plugins > Add New > Upload Plugin**
3. Upload the ZIP and click **Install Now**
4. Click **Activate Plugin**

### Manual (Development)

```bash
cd wp-content/plugins/
git clone https://github.com/brainstormforce/convertplug.git
```

Then activate via **WP Admin > Plugins**.

### Post-Activation

On first activation:
- The MaxMind uploads directory is created at `wp-content/uploads/convertplus_uploads/`
- You are redirected to the **Get Started** page
- All three modules (Modal, Slide-In, Info Bar) are enabled by default

## Creating Your First Campaign

A **campaign** links a conversion module to an email list (or local storage).

1. Go to **WP Admin > Campaigns > Create New Campaign**
2. **Step 1**: Enter a campaign name (e.g. "Newsletter Subscribers")
3. **Step 2**: Select a list provider
   - Choose **Convert Plug** to store subscribers locally
   - Or select an installed email provider addon (MailChimp, AWeber, etc.)
4. Click **Save**

## Creating Your First Modal

1. Go to **WP Admin > Convert Plus** (the main dashboard)
2. Click **Modal Popup** in the module list
3. Click **Create New** (or choose a preset/theme)
4. In the customizer:
   - Design your modal content
   - Under **Mailer**, select the campaign you created
   - Under **Triggers**, configure when the modal should appear (e.g. "5 seconds after page load")
   - Under **Targeting**, choose which pages to show it on
5. Click **Save**
6. Set the modal status to **Active** (green toggle)

The modal will now appear on your configured pages.

## Enabling / Disabling Modules

1. Go to **WP Admin > Convert Plus > Modules**
2. Toggle the switches to enable or disable Modal Popup, Info Bar, or Slide In Popup
3. Save

Disabled modules are not loaded and their admin menu items disappear.

## Global Settings

Go to **WP Admin > Convert Plus > Settings** to configure:

- **Access Roles** — which WordPress user roles can manage Convert Plus
- **Async CSS Loading** — load plugin CSS asynchronously for better performance
- **Google reCAPTCHA** — site key and secret key for form spam protection

## Setting Up Geolocation

To use country-based targeting:

1. Sign up for a free MaxMind account and obtain a GeoLite2 license key
2. Go to **Convert Plus > Settings** and enter the license key
3. Click **Download Database**
4. Set country targeting rules when editing any style

See [Geolocation Targeting](Geolocation-Targeting) for full details.

## Viewing Analytics

Go to **WP Admin > Campaigns > [Campaign Name] > Analytics** to see:

- Total impressions and conversions
- Conversion rate
- Day-by-day chart

Per-style analytics are available from each module's style list.

## Next Steps

- [Module System](Module-System) — detailed module documentation
- [Campaigns and Contacts](Campaigns-and-Contacts) — managing subscribers
- [Email Integrations](Email-Integrations) — connecting external providers
- [Admin Panels](Admin-Panels) — full admin UI reference
- [Troubleshooting FAQ](Troubleshooting-FAQ) — common issues and fixes
