# Analytics System

Convert Plus includes a built-in analytics system that tracks impressions (how many times a campaign was shown) and conversions (how many times a visitor subscribed or clicked through).

## Data Points Tracked

| Metric | Description |
|--------|-------------|
| Impressions | Each time a style (modal/slide-in/info bar) is displayed to a visitor |
| Conversions | Each successful form submission or click-through |
| Conversion Rate | Calculated as `(conversions / impressions) * 100` |

Analytics are tracked per **style** (individual campaign design), not per email provider list.

## Storage

Analytics data is stored in WordPress options. Each style has its own analytics entry, keyed by `style_id`. The data includes daily counts used for time-series charting.

The global analytics time range is managed via:

```php
global $cp_analytics_start_time, $cp_analytics_end_time, $cp_default_dateformat;
$cp_analytics_end_time = current_time( 'd-m-Y' );
```

The colour palette for charts is defined in `convertplug.php`:

```php
$color_pallet = array(
    'rgba(26, 188, 156,1.0)',  // teal
    'rgba(46, 204, 113,1.0)',  // green
    'rgba(52, 152, 219,1.0)',  // blue
    // ...10 colours total
);
```

## Impression Tracking

Impressions are incremented via the public AJAX action `smile_update_impressions`. This is called from the front-end JavaScript when a style becomes visible to the visitor.

**Handler:** `smile_update_impressions()` in `admin/ajax-actions.php`

- Accepts: `style_id`, nonce
- Increments the impression counter for the given style
- Available to non-authenticated users (`wp_ajax_nopriv_`)

## Conversion Tracking

Conversions are incremented by `smile_update_conversions( $style_id )`, called internally from `cp_add_subscriber` on successful form submission.

**Handler:** `smile_update_conversions()` in `admin/ajax-actions.php`

- Called server-side (not directly exposed as a public endpoint)
- Increments conversion counter and stores the daily conversion data point

## Admin Analytics Views

### Campaign Analytics (`?view=analytics`)

Available from **WP Admin > Campaigns > [Campaign Name] > Analytics**.

AJAX actions used:

| Action | Handler | Description |
|--------|---------|-------------|
| `get_campaign_analytics_data` | `get_campaign_analytics_data()` | Returns aggregated impression/conversion totals for a campaign across all its styles |
| `get_campaign_daywise_data` | `get_campaign_daywise_data()` | Returns day-by-day data for time-series chart rendering |

### Style Analytics (`?view=analytics` per style)

Each individual style within a module has its own analytics sub-view (e.g. `modules/modal/views/analytics.php`).

AJAX actions used:

| Action | Handler | Description |
|--------|---------|-------------|
| `get_style_analytics_data` | `get_style_analytics_data()` | Returns analytics data for a single style, with date-range filtering |
| `get_style_analtics_range` | `get_style_analtics_range()` | Returns analytics data for a custom date range |

### Date Range Helpers

| Function | Description |
|----------|-------------|
| `get_dates_from_range( $start, $end, $format )` | Returns an array of all dates between two dates |
| `get_style_analtics_range( $start, $end, $format, $type )` | Returns analytics data filtered to a date range |

## Resetting Analytics

Analytics for a style can be reset from the style analytics view.

**AJAX action:** `cp_reset_analytics_action` → calls `cp_reset_analytics( $style_id )`

This wipes all impression and conversion data for the given style.

## Exporting Analytics

Analytics can be exported as a CSV file.

**Admin POST action:** `cp_export_analytics` → `cp_export_analytics()`

The export contains per-style analytics data including date-range breakdowns.

## Average Calculation

`cp_calculate_average( $arr )` computes the average of an array of numeric values. Used for summary statistics in analytics displays.

## Related Pages

- [Campaigns and Contacts](Campaigns-and-Contacts)
- [AJAX Actions Reference](AJAX-Actions-Reference)
- [Admin Panels](Admin-Panels)
