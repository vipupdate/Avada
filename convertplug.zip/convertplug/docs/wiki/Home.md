# Convert Plus — Developer Wiki

**Convert Plus** is a WordPress plugin by [Brainstorm Force](https://www.brainstormforce.com) that converts website visitors into leads through modal popups, slide-in popups, and info bars.

- **Version:** 3.6.2
- **License:** GPL v2 or later
- **Text Domain:** `smile`
- **Repository:** https://github.com/brainstormforce/convertplug

---

## Quick Navigation

### Getting Started
- [Getting Started](Getting-Started) — Installation, first campaign, first modal
- [Architecture Overview](Architecture-Overview) — How the plugin is structured
- [Plugin Structure](Plugin-Structure) — Directory layout and entry points

### Core Concepts
- [Smile Framework](Smile-Framework) — Internal framework: modules, addons, field types
- [Module System](Module-System) — Modal Popup, Slide-In, Info Bar modules
- [Campaigns and Contacts](Campaigns-and-Contacts) — Campaign creation and subscriber management
- [Analytics System](Analytics-System) — Impression and conversion tracking
- [Email Integrations](Email-Integrations) — Addon-based email provider connections
- [Geolocation Targeting](Geolocation-Targeting) — MaxMind GeoLite2 country targeting

### Admin Reference
- [Admin Panels](Admin-Panels) — All admin pages and settings
- [AJAX Actions Reference](AJAX-Actions-Reference) — All `wp_ajax_*` and `admin_post_*` handlers
- [Environment Configuration](Environment-Configuration) — Constants, options, minimum requirements

### Development
- [Build Tooling](Build-Tooling) — Grunt, npm scripts, linting, i18n
- [Testing Guide](Testing-Guide) — PHPStan, PHPCS, manual testing
- [Contributing Guide](Contributing-Guide) — Coding standards, PR workflow, security rules
- [Deployment Guide](Deployment-Guide) — Release process and pre-deployment checklist

### Reference
- [Troubleshooting FAQ](Troubleshooting-FAQ) — Common issues and solutions
- [Changelog](Changelog) — Recent version history

---

## Architecture at a Glance

```
convertplug.php
    └── Convert_Plug (extends Smile_Framework)
            ├── modules/modal/       ← Modal Popup
            ├── modules/slide_in/    ← Slide-In Popup
            ├── modules/info_bar/    ← Info Bar
            ├── admin/contacts/      ← Campaign & subscriber management
            ├── admin/ajax-actions.php  ← All backend handlers
            └── framework/           ← Smile Framework (options, fields, addons)
```

## Key Technologies

| Technology | Purpose |
|------------|---------|
| PHP 5.3+ | Plugin backend |
| WordPress hooks API | Integration with WordPress core |
| jQuery / Vanilla JS | Front-end campaign display and triggers |
| Grunt + npm | Build, minification, i18n |
| PHPCS / WPCS | PHP code style enforcement |
| PHPStan (level 9) | Static analysis |
| MaxMind GeoLite2 | Country-based visitor targeting |
| BSF Analytics | Usage analytics (opt-in) |
| BSF Core | License management and auto-updates |
