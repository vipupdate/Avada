# AJAX Actions Reference

All AJAX and form handlers are defined in `admin/ajax-actions.php`. Actions are registered dynamically:

```php
add_action( 'wp_ajax_' . $event_slug, $event_slug );
// Some actions also allow non-authenticated users:
add_action( 'wp_ajax_nopriv_' . $event_slug, $event_slug );
```

## Style / Campaign Management

| Action | Auth | Description |
|--------|------|-------------|
| `cp_trash_list` | admin | Moves a campaign to trash |
| `update_style_settings` | admin | Saves customizer settings for a style |
| `update_variant_test_settings` | admin | Updates A/B variant test configuration |
| `smile_duplicate_style` | admin | Duplicates an existing style |
| `smile_update_status` | admin | Enables/disables a style |
| `smile_delete_style` | admin | Permanently deletes a style |
| `cp_delete_all_modal_action` | admin | Deletes all styles for a module |
| `smile_update_modules` | admin | Saves enabled/disabled module list |
| `smile_update_global` | admin | Updates global settings |
| `smile_duplicate_style_name` | admin | Generates a unique duplicate name |

## Subscriber / List Management

| Action | Auth | Description |
|--------|------|-------------|
| `smile_add_list` | admin | Creates a new campaign (list) |
| `is_campaign_exists` | admin | Checks if a campaign name already exists |
| `cp_add_subscriber` | public | Processes opt-in form submission; routes to correct provider |
| `cp_add_subscriber_contact` | internal | Saves subscriber to local `smile_lists` option |
| `cp_is_list_assigned` | admin | Checks if any campaign is assigned to a style |

## Analytics

| Action | Auth | Description |
|--------|------|-------------|
| `smile_update_impressions` | public | Increments impression count for a style |
| `smile_update_conversions` | internal | Increments conversion count for a style |
| `get_campaign_analytics_data` | admin | Returns impression/conversion data for a campaign |
| `get_campaign_daywise_data` | admin | Returns day-by-day analytics data |
| `get_style_analytics_data` | admin | Returns analytics data for a specific style |
| `cp_reset_analytics` | admin | Resets all analytics data for a style |
| `cp_reset_analytics_action` | admin | AJAX wrapper for `cp_reset_analytics` |

## Settings & Debug

| Action | Auth | Description |
|--------|------|-------------|
| `smile_update_settings` | admin | Saves global plugin settings |
| `smile_update_debug` | admin | Saves debug panel settings |
| `cp_google_recaptcha` | admin | Saves Google reCAPTCHA site/secret keys |
| `cplus_maxmind` | admin | Downloads/updates MaxMind GeoLite2 database |
| `cp_dismiss_phardata_notice` | admin | Dismisses the PharData admin notice |

## Data Queries

| Action | Auth | Description |
|--------|------|-------------|
| `cp_get_posts_by_query` | admin | Searches posts/pages for targeting rules |
| `cp_get_active_campaigns` | admin | Returns list of active (non-trashed) campaigns |
| `cp_get_taxonomy_by_id` | admin | Returns taxonomy term by ID |

## Import / Export

| Action | Auth | Description |
|--------|------|-------------|
| `cp_import_presets` | admin | Step 1: validates and extracts an uploaded import zip |
| `cp_import_presets_step2` | admin | Step 2: completes the import |

## Preview

| Action | Auth | Description |
|--------|------|-------------|
| `cp_display_preview_modal` | admin | Renders modal preview HTML |
| `cp_display_preview_info_bar` | admin | Renders info bar preview HTML |
| `cp_display_preview_slide_in` | admin | Renders slide-in preview HTML |

## Admin POST Actions (non-AJAX)

Registered via `add_action( 'admin_post_*' )`. Used for file downloads / exports.

| Action | Handler | Description |
|--------|---------|-------------|
| `cp_export_list` | `handle_cp_export_list_action` | Exports contacts for a single campaign as CSV |
| `cp_export_all_list` | `handle_cp_export_all_list_action` | Exports contacts from all campaigns as CSV |
| `cp_export_modal` | `cp_export_modal_action` | Exports a modal style as ZIP |
| `cp_export_infobar` | `cp_export_infobar_action` | Exports an info bar style as ZIP |
| `cp_export_slidein` | `cp_export_slidein_action` | Exports a slide-in style as ZIP |
| `cp_export_analytics` | `cp_export_analytics` | Exports analytics data as CSV |

## Subscriber Submission Flow

The public `cp_add_subscriber` action handles front-end form submissions:

1. Verifies nonce: `cp-submit-form-{style_id}`
2. Reads `mailer_id` and `list_id` from hidden form fields
3. If `mailer_id === 'cp'`: saves subscriber to `smile_lists[{list_id}]` via `cp_add_subscriber_contact()`
4. If external provider: delegates to the registered addon handler
5. Triggers `smile_update_conversions()` on success
6. Returns JSON response with success/error message

## Nonce Reference

| Nonce | Action | Used In |
|-------|--------|---------|
| `cp-submit-form-{style_id}` | Form submission | Front-end opt-in forms |
| `cp-create-list-nonce` | Campaign creation | New campaign wizard |
| `is_campaign_exists_nonce` | Duplicate check | New campaign wizard (JS) |
| `cp_admin_page` | Admin page access | All admin views |
| `cp_media_nonce` | Media uploader | Style customizer |

## Related Pages

- [Campaigns and Contacts](Campaigns-and-Contacts)
- [Analytics System](Analytics-System)
- [Module System](Module-System)
- [Admin Panels](Admin-Panels)
