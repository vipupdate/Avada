# Email Integrations

Convert Plus uses an **addon-based integration model**. The core plugin provides local subscriber storage out of the box. Email service provider integrations (MailChimp, AWeber, ActiveCampaign, etc.) are provided by separate addon plugins.

## How the Addon System Works

Each email provider addon registers itself by calling:

```php
Smile_Framework::smile_add_mailer( 'provider-slug', $setting_array );
```

This adds the provider to `Smile_Framework::$addon_list`. The addon list is then:

1. Passed to the campaign creation wizard via `wp_localize_script` as `cplus_connect_list.addons_lists`
2. Rendered as `<option>` elements in the "List Provider" dropdown

When a campaign is created with a provider selected, that provider's credentials and list ID are saved into the `smile_lists` option for that campaign.

## Built-in Provider: Convert Plug

When no addons are installed, the only available provider is **Convert Plug**. This stores subscribers directly in WordPress (`smile_lists[{list_id}]['subscribers']`) with no external API calls.

| Feature | Details |
|---------|---------|
| Storage | WordPress options table (`smile_lists`) |
| Export | CSV download via `cp_export_list` |
| Subscriber fields | Email, Name, any additional form fields |

## Addon Plugins

The following Connect addon plugins are known to integrate with Convert Plus (referenced in `Convert_Plug::cp_skip_brainstorm_menu()`):

| Addon Slug | Description |
|------------|-------------|
| `connects-contact-form-7` | Contact Form 7 integration |
| `connects-woocommerce` | WooCommerce integration |
| `connects-ontraport` | Ontraport CRM |
| `connects-wp-registration-form` | WP Registration Form |
| `connects-wp-comment-form` | WP Comment Form |
| `converts-totalsend` | TotalSend |
| `connects-sendreach` | SendReach |
| `connects-convertfox` | ConvertFox (now Gist) |
| `convertplug-vc` | WPBakery Visual Composer integration |

> Email service providers (MailChimp, AWeber, ActiveCampaign, GetResponse, etc.) each have their own addon plugin that registers via `smile_add_mailer`.

## Subscriber Routing

When `cp_add_subscriber` receives a form submission:

```
mailer_id === 'cp'
    → cp_add_subscriber_contact() → saves to smile_lists

mailer_id === '{provider-slug}'
    → Addon plugin handles API call to external service
```

The `mailer_id` and `list_id` are embedded as hidden fields in the opt-in form by `cp_get_form_hidden_fields()`.

## MailChimp Tags

Convert Plus has specific handling for MailChimp tags (referenced in `cp_add_subscriber`):

```php
$mailchimp_selected_tags = isset( $data['mailchimp_selected_tags'] )
    ? json_decode( stripslashes( $data['mailchimp_selected_tags'] ), true )
    : array();
```

Tags are sent as a JSON-encoded array of tag names from the style's customizer settings.

## On-Success Actions

After a successful subscription, the form can perform one of these actions (configured per style):

| Action | Description |
|--------|-------------|
| Show success message | Displays a custom HTML/text message |
| Redirect | Redirects visitor to a specified URL |
| Download | Redirects to a download URL (lead magnet) |

These are configured in the style customizer and passed as hidden form fields.

## Google reCAPTCHA

Convert Plus supports Google reCAPTCHA v2 on opt-in forms. Keys are configured from the Settings panel.

**AJAX action:** `cp_google_recaptcha` — saves site key and secret key to `convert_plug_settings`.

**Handler:** `cp_google_recaptcha()` in `admin/ajax-actions.php`

**Manager class:** `framework/google-recaptcha-manager.php`

When enabled, the reCAPTCHA widget is rendered inside the opt-in form, and the server-side verification is performed during `cp_add_subscriber` before saving the subscriber.

## Multi-Form Component

Convert Plus supports multi-step forms via `framework/functions/component-multi-form.php`. This allows campaigns to collect additional data across form steps before final submission.

## Related Pages

- [Campaigns and Contacts](Campaigns-and-Contacts)
- [Smile Framework](Smile-Framework)
- [Module System](Module-System)
- [AJAX Actions Reference](AJAX-Actions-Reference)
