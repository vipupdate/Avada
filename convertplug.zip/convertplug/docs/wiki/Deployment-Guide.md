# Deployment Guide

## Release Process

Convert Plus releases are managed by the Brainstorm Force team. This guide covers how a release build is created and what needs to be verified before deploying.

## Pre-Deployment Checklist

Before cutting a release:

- [ ] All changes merged into `dev` branch
- [ ] `composer run lint` — no PHPCS violations
- [ ] `composer run phpstan` — no PHPStan errors (or all suppressions justified in baseline)
- [ ] `npm run lint:js` — no ESLint errors
- [ ] `npm run lint:css` — no stylelint errors
- [ ] `changelog.txt` updated with version and date
- [ ] Version bumped in `convertplug.php` (`CP_VERSION` constant)
- [ ] Version bumped in `package.json`
- [ ] Test on latest WordPress version
- [ ] Test on PHP 7.4, 8.0, 8.1, 8.2
- [ ] Manual smoke test: create campaign, create style, test opt-in form submission
- [ ] No hardcoded credentials or debug code left in

## Version Bump

Use Grunt to bump the version across all files:

```bash
grunt bumpup:patch     # 3.6.1 → 3.6.2
grunt bumpup:minor     # 3.6.x → 3.7.0
grunt bumpup:major     # 3.x.x → 4.0.0
```

This updates:
- `package.json` version field
- `convertplug.php` `CP_VERSION` constant and plugin header `Version:`

After bumping, also manually update `changelog.txt`.

## Building Assets

Assets are compiled per-module and for the root plugin:

```bash
# Install dependencies
npm install

# Compile and minify all assets from the root
grunt

# Per-module (run from module directory)
cd modules/modal && npm install && grunt
cd modules/slide_in && npm install && grunt
cd modules/info_bar && npm install && grunt
```

## Creating the Release ZIP

```bash
grunt compress
```

This produces a distributable ZIP in the `artifact/` directory, excluding development files (`node_modules/`, `vendor/`, `tests/`, `.git/`, etc.).

## Environment-Specific Notes

### MaxMind Database

The GeoLite2-Country database is **not bundled** with the plugin ZIP. Each site admin must download it separately using their own MaxMind license key from within the plugin settings.

On upgrade, the database directory is preserved at `wp-content/uploads/convertplus_uploads/`.

### WordPress Options Migration

When the plugin version changes (detected by comparing `cp_previous_version` to `CP_VERSION`), the following upgrade routines run automatically on next page load:

1. `create_cplus_maxmind_folder_on_activation()` — creates/verifies uploads directory
2. `cplus_google_font_create_update()` — migrates Google Fonts settings from Ultimate Addons
3. `cp_delete_preset_screenshots()` — cleans up old preset screenshot cache

No manual database migration steps are required for standard updates.

### BSF Analytics

BSF Analytics (`admin/bsf-analytics/`) is a Composer-managed library. It shows an opt-in consent notice 24 hours after activation (`time_to_display => '+24 hours'`). This is standard Brainstorm Force product behaviour.

### BSF Core (License Manager)

`admin/bsf-core/` provides:
- Envato license activation (`class-bsf-envato-activate.php`)
- Auto-update management (`class-bsf-update-manager.php`)
- Rollback version manager (`class-bsf-rollback-version-manager.php`)

License activation is done inline on the Plugins page (no separate settings page).

## Multisite Deployment

Convert Plus is multisite-compatible. On multisite:

- The registration page URL is `network_admin_url( 'plugins.php?bsf-inline-license-form=14058953' )`
- `bsf_force_check_extensions` is set via `update_site_option()` on activation

## Rollback

In the event a release needs to be rolled back:

1. The BSF Core `class-bsf-rollback-version-manager.php` provides rollback capability from within WP Admin
2. Alternatively, install the previous version ZIP manually

No database changes are made that would prevent a rollback.

## Related Pages

- [Build Tooling](Build-Tooling)
- [Contributing Guide](Contributing-Guide)
- [Environment Configuration](Environment-Configuration)
- [Troubleshooting FAQ](Troubleshooting-FAQ)
