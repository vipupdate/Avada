# Environment Configuration

## Plugin Constants

All constants are defined in `convertplug.php` and guarded with `if ( ! defined(...) )` checks to allow override by the environment.

| Constant | Description | Example Value |
|----------|-------------|---------------|
| `CP_VERSION` | Current plugin version | `3.6.2` |
| `CP_BASE_DIR` | Absolute filesystem path to plugin root (trailing slash) | `/wp-content/plugins/convertplug/` |
| `CP_BASE_URL` | Absolute URL to plugin root (trailing slash) | `https://example.com/wp-content/plugins/convertplug/` |
| `CP_PLUGIN_URL` | Same as `CP_BASE_URL` | — |
| `__CP_ROOT__` | Plugin root without trailing slash (`dirname(__FILE__)`) | — |
| `CP_DIR_NAME` | Plugin directory basename | `convertplug` |
| `CP_DIR_FILE_NAME` | Plugin file basename | `convertplug/convertplug.php` |
| `CP_PLUS_NAME` | Human-readable plugin name | `Convert Plus` |
| `CP_PLUS_SLUG` | Admin menu slug | `convert-plus` |
| `SMILE_FRAMEWORK_DIR` | Absolute path to `framework/` | — |
| `SMILE_FRAMEWORK_URI` | URL to `framework/` | — |
| `BSF_REMOVE_14058953_FROM_REGISTRATION_LISTING` | Always `true` — hides product from BSF registration list | `true` |

## WordPress Options

These options are stored in the WordPress `wp_options` table and control plugin behaviour at runtime.

| Option Key | Type | Description |
|------------|------|-------------|
| `convert_plug_settings` | array | Global plugin settings (CSS async loading, access roles, etc.) |
| `convert_plug_modules` | array | List of enabled module slugs (`Modal_Popup`, `Info_Bar`, `Slide_In_Popup`) |
| `convert_plug_debug` | array | Debug settings including `cp-dev-mode` and `cp-display-debug-info` |
| `smile_lists` | array | All campaigns — keyed by campaign ID, contains list name, provider, credentials, subscribers |
| `cp_previous_version` | string | Last installed version — used for upgrade routines |
| `cp_is_new_user` | bool | `true` if user installed fresh (no prior version) |
| `convert_plug_redirect` | bool | `true` on activation; triggers redirect to Get Started page |
| `convertplus_maxmind_geolocation_settings` | array | Contains `database_prefix` (random 32-char string) and `license_key` |
| `cp_show_phardata_notice` | string | Controls the PharData admin notice visibility |
| `cp_is_displayed_debug_info` | bool | Whether debug info was shown this request; reset to `false` on each `wp_loaded` |
| `dismiss-cp-update-notice` | bool | Whether the update notice has been dismissed |
| `cplus_ultimate_google_fonts` | mixed | Google Fonts list (migrated from Ultimate Addons on upgrade) |

## Key Settings Fields (`convert_plug_settings`)

| Key | Description |
|-----|-------------|
| `cp-load-syn` | `1` = load CSS asynchronously (performance mode) |
| `cp-access-role` | Comma-separated list of WP role slugs that can access Convert Plus |
| `cp-dev-mode` | Enables developer mode (loads unminified assets) |

## Minimum Requirements

| Requirement | Minimum Version |
|-------------|-----------------|
| PHP | 5.3.2 (activation check), 5.4 (runtime notice) |
| WordPress | 3.5 |

> The activation hook will deactivate the plugin and show a `wp_die()` error if PHP < 5.3.2 or WordPress < 3.5.

## Text Domain

The plugin uses `smile` as its text domain (loaded on `plugins_loaded`). Translation files are located in:

- `lang/smile.pot` — translation template
- `lang/smile-{locale}.po` / `.mo` — compiled translations
- `lang/smile-{locale}-{hash}.json` — JS translations (for `@wordpress/i18n`)

## Development Mode

Enable dev mode via the Debug panel (`Admin > Convert Plus > Settings > Debug tab`) or by setting `convert_plug_debug['cp-dev-mode']` to a truthy value. In dev mode, the plugin loads unminified JS and CSS assets.

## Related Pages

- [Plugin Structure](Plugin-Structure)
- [Architecture Overview](Architecture-Overview)
- [Troubleshooting FAQ](Troubleshooting-FAQ)
