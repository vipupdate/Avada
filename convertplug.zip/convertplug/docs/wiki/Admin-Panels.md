# Admin Panels

Convert Plus registers its admin UI under **WP Admin > Convert Plus** (`?page=convert-plus`). The main admin router is `admin/admin.php`, which dispatches to sub-views based on the `?view=` query parameter.

## Navigation Tabs

| Tab | URL Parameter | File |
|-----|---------------|------|
| Get Started | `?page=convert-plus` (default) | `admin/get-started.php` |
| Modules | `?view=modules` | `admin/modules.php` |
| Settings | `?view=settings` | `admin/settings.php` |
| Knowledge Base | `?view=knowledge_base` | `admin/knowledge-base.php` |
| Debug | `?view=debug&author=true` | `admin/debug.php` |

The admin menu is registered in `Convert_Plug::add_admin_menu()` and its order adjusted by `cp_submenu_order()`.

## Get Started

The welcome/onboarding screen. Displays plugin version and a brief description. Also shows the BSF product registration status (licensed vs. unregistered).

## Modules

Lists the three available modules (Modal Popup, Info Bar, Slide In Popup) with toggle switches. Saves enabled modules to the `convert_plug_modules` option.

AJAX action: `smile_update_modules`

## Settings

Global settings panel. Key configurable options:

| Setting | Option Key | Description |
|---------|------------|-------------|
| Async CSS Loading | `cp-load-syn` | Load plugin CSS asynchronously for performance |
| Access Roles | `cp-access-role` | Comma-separated WP roles that can manage Convert Plus |

AJAX action: `smile_update_settings`

The settings page also includes a Google reCAPTCHA configuration section (Site Key / Secret Key). AJAX action: `cp_google_recaptcha`

## Debug Panel

The debug panel allows developers to:

- Enable Dev Mode (`cp-dev-mode`) — loads unminified JS/CSS
- Enable Debug Info display in admin footer (`cp-display-debug-info`)
- Reset plugin data

AJAX action: `smile_update_debug`

Access requires the `?view=debug&author=true` URL parameter.

## Contacts (Campaign Manager)

A separate menu entry: **WP Admin > Campaigns** (`?page=contact-manager`). Routed via `admin/contacts/admin.php`.

Sub-views:

| View | URL | Description |
|------|-----|-------------|
| Dashboard | `?page=contact-manager` | Lists all campaigns with subscriber counts |
| New Campaign | `?view=new-list` | 2-step wizard to create a campaign |
| Contacts | `?view=contacts&list=<id>` | View subscribers for a specific campaign |
| Analytics | `?view=analytics&list=<id>` | Per-campaign impression/conversion analytics |
| Contact Details | `?view=contact-details` | Individual subscriber details |

### Creating a Campaign (2-Step Wizard)

**Step 1:** Enter campaign name.

**Step 2:** Select email list provider from the addon list. If no addons are installed, the only option is "Convert Plug" (stores subscribers locally).

The wizard calls the `smile_add_list` AJAX action to save the campaign.

## Access Control

The plugin defines a custom capability `access_cp`. It is granted to any role listed in `convert_plug_settings['cp-access-role']` plus `administrator` (always granted).

Capability assignment runs on `wp_loaded` via `Convert_Plug::cp_access_capabilities()`.

## Nonce Verification

All admin page views that process `$_REQUEST` data check:

```php
if ( isset( $_REQUEST['cp_admin_page_nonce'] ) && ! wp_verify_nonce( $_REQUEST['cp_admin_page_nonce'], 'cp_admin_page' ) ) {
    wp_die( 'No direct script access allowed!' );
}
```

The nonce `cp_admin_page` is output on all admin pages.

## Plugin Action Links

Two sets of action links are added to the Plugins page:

1. `cp_action_links` — adds "Settings" link
2. `cp_license_form_and_links` — adds inline Envato license form (if BSF Core is active)

## Related Pages

- [Campaigns and Contacts](Campaigns-and-Contacts)
- [Analytics System](Analytics-System)
- [AJAX Actions Reference](AJAX-Actions-Reference)
- [Environment Configuration](Environment-Configuration)
