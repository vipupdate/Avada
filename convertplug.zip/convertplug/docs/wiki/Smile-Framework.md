# Smile Framework

The Smile Framework is Convert Plus's internal PHP framework, located in `framework/`. It provides module/addon registration, options storage, field type rendering, and the style customizer infrastructure.

## Class: `Smile_Framework`

**File:** `framework/class-smile-framework.php`

`Convert_Plug` extends `Smile_Framework`. It is the base class for the plugin.

### Static Properties

| Property | Type | Description |
|----------|------|-------------|
| `$options` | `array` | Stores registered campaign/style settings definitions |
| `$modules` | `array` | Registered conversion modules |
| `$addon_list` | `array` | Registered email provider addons (keyed by slug) |

### Key Static Methods

#### `smile_add_mailer( $slug, $setting )`
Registers an email provider addon into `$addon_list`. Called by addon plugins (e.g. a MailChimp connector). The `$slug` becomes the provider key.

```php
Smile_Framework::smile_add_mailer( 'mailchimp', $setting_array );
```

#### `smile_store_data( $class, $name, $settings )`
Stores a style/campaign settings definition into `$options[$name]`.

#### `smile_update_data( $class, $name, $settings )`
Appends additional options to an existing entry in `$options[$name]['options']`.

#### `smile_update_value( $class, $style, $name, $value )`
Updates a specific option value within a stored style definition.

#### `smile_remove_setting( $class, $style, $name )`
Removes a specific setting key from a stored style definition.

#### `smile_update_partial_refresh( $class, $style, $name, $parse_array )`
Updates partial refresh settings for live preview.

### Hooks Registered by `Smile_Framework`

| Hook | Callback | Description |
|------|----------|-------------|
| `init` | `load_framework_functions` | Loads mapper, style framework, field types |
| `admin_head` | `load_compatible_scripts` | Enqueues customizer scripts when `hidemenubar` param is set |

### Framework Load Sequence (`load_framework_functions`)

On `init`, the framework loads:

1. `framework/classes/class-smile-framework-mapper.php` — field type registry
2. `framework/classes/class.style-framework.php` — style/campaign data layer
3. `framework/classes/class-cpimport.php` — import handler
4. `framework/functions/functions.php` — admin utility functions
5. All `framework/lib/fields/**/*.php` — field type definitions (glob loaded)

## Class: `Convert_Plug_Smile_Framework_Mapper`

**File:** `framework/classes/class-smile-framework-mapper.php`

Manages custom input field types used in the style customizer.

### Methods

#### `add_input_type( $type, $callback )`
Registers a new field type with a render callback.

```php
Convert_Plug_Smile_Framework_Mapper::add_input_type( 'color', 'my_color_field_callback' );
```

#### `render_input_type( $name, $type, $settings, $value, $default )`
Renders a registered field type by calling its callback. Returns the HTML string.

## Field Types

Field type PHP files live in `framework/lib/fields/`. Each subdirectory contains a field type (e.g. `text`, `color`, `select`, `border`, `image`, etc.). They are auto-loaded via `glob()`.

## Customizer Scripts

When the admin URL includes `?hidemenubar=1`, the framework loads:

- `framework/assets/js/cp-helper.js` — media uploader helper
- `framework/assets/js/customizer.js` — live style customizer logic

These power the in-plugin style editor used when editing modals, slide-ins, and info bars.

## Addon / Mailer Integration

Email provider addons are separate plugins that call `Smile_Framework::smile_add_mailer()` to register themselves. The available providers then appear as options in the "Create New Campaign" wizard under "List Provider".

The addon list is passed to the admin UI via `wp_localize_script`:

```php
wp_localize_script( 'convert-plug-connects-list', 'cplus_connect_list', array(
    'addons_lists' => Smile_Framework::$addon_list,
    ...
));
```

## Related Pages

- [Architecture Overview](Architecture-Overview)
- [Module System](Module-System)
- [Email Integrations](Email-Integrations)
- [Campaigns and Contacts](Campaigns-and-Contacts)
