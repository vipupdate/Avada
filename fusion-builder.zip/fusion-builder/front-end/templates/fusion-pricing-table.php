<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 2.0
 */

?>
<script type="text/html" id="tmpl-fusion_pricing_table-shortcode">
	<div {{{ _.fusionGetAttributes( tableData ) }}}></div>
</script>
<script type="text/html" id="tmpl-fusion_pricing_column-shortcode">
	<div class="panel-container">
		<# if ( badgeText && ! badgeInHeading ) { #>
			<span class="awb-pricing-table__badge awb-pricing-table__badge--{{ badgePosition }}<# if ( badgeWrapped ) { #> awb-pricing-table__badge--wrapped<# } #>"><span class="awb-pricing-table__badge-text">{{{ badgeText }}}</span></span>
		<# } #>
		<div class="fusion-panel">
			<div class="panel-heading awb-pricing-table__heading">
				<# if ( badgeText && badgeInHeading ) { #>
					<span class="awb-pricing-table__badge awb-pricing-table__badge--{{ badgePosition }}"><span class="awb-pricing-table__badge-text">{{{ badgeText }}}</span></span>
				<# } #>
				<{{ titleTag }} {{{ _.fusionGetAttributes( titleAttr ) }}}>{{{ title }}}</{{ titleTag }}>

				<# if ( subTitle ) { #>
					<span class="awb-pricing-table__sub-title">{{{ subTitle }}}</span>
				<# } #>

				<# if ( description ) { #>
					<p class="awb-pricing-table__description">{{{ description }}}</p>
				<# } #>
			</div>

			<# if ( ! price ) { #>
				<div class="panel-body pricing-row">
					<# if ( priceAbove ) { #>
						<div class="awb-pricing-table__price-above"><span>{{{ priceAbove }}}</span></div>
					<# } #>
					<# if ( priceBelow ) { #>
						<div class="awb-pricing-table__price-below"><span>{{{ priceBelow }}}</span></div>
					<# } #>
				</div>
			<# } else { #>

				<div class="panel-body pricing-row">
					<# if ( priceAbove ) { #>
						<div class="awb-pricing-table__price-above"><span>{{{ priceAbove }}}</span></div>
					<# } #>
					<div class="price<# if ( 1 < price.length ) { #> price-with-decimal<# } #>">
						<# if ( 'right' !== currencyPosition ) { #>
							<span class="currency">{{{ currency }}}</span>
						<# } #>

						<span class="integer-part">{{{ price[0] }}}</span>

						<# if ( 'undefined' !== typeof price[1] ) { #>
							<sup class="decimal-part">{{{ price[1] }}}</sup>
						<# } #>

						<# if ( 'right' === currencyPosition ) { #>

							<span {{{ _.fusionGetAttributes( currencyClasses ) }}}>{{{ currency }}}</span>

							<# if ( time ) { #>
								<span {{{ _.fusionGetAttributes( timeClasses ) }}}>{{{ time }}}</span>
							<# } #>
						<# } #>

						<# if ( time && 'right' !== currencyPosition ) { #>

							<span {{{ _.fusionGetAttributes( timeClasses ) }}}>{{{ time }}}</span>
						<# } #>
					</div>

					<# if ( priceBelow ) { #>
						<div class="awb-pricing-table__price-below"><span>{{{ priceBelow }}}</span></div>
					<# } #>
				</div>

			<# } #>

			<# if ( footerAfterPrice && footerContent ) { #>
				<div class="panel-footer footer-row">{{{ FusionPageBuilderApp.renderContent( footerContent, cid, false ) }}}</div>
			<# } #>

			<# if ( 'object' === typeof featureRows ) { #>
				<ul class="list-group">
					<# _.each( featureRows, function( featureRow )  { #>
						<#
						var isExcluded = 0 === featureRow.replace( /^\s+/, '' ).indexOf( '- ' ),
							rowContent = isExcluded ? featureRow.replace( /^\s+/, '' ).substring( 2 ) : featureRow,
							rowIcon    = isExcluded && featuresExcludedIcon ? featuresExcludedIcon : featuresIcon;
						#>
						<li class="list-group-item normal-row<# if ( isExcluded ) { #> awb-pricing-table__feature--excluded<# } #>">
							<# if ( rowIcon || isExcluded ) { #>
								<# if ( rowIcon ) { #><span class="awb-pricing-table__feature-icon"><i class="{{ rowIcon }}" aria-hidden="true"></i></span><# } #>
								<span class="awb-pricing-table__feature-text">{{{ FusionPageBuilderApp.renderContent( rowContent, cid, false ) }}}</span>
							<# } else { #>
								{{{ FusionPageBuilderApp.renderContent( featureRow, cid, false ) }}}
							<# } #>
						</li>
					<# } ); #>
				</ul>
			<# } #>

			<# if ( ! footerAfterPrice && footerContent ) { #>
				<div class="panel-footer footer-row">{{{ FusionPageBuilderApp.renderContent( footerContent, cid, false ) }}}</div>
			<# } #>
		</div>
	</div>
</script>
