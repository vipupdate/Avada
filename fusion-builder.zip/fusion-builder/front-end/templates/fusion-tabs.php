<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 2.0
 */

?>
<script type="text/html" id="tmpl-fusion_tabs-shortcode">
	<div {{{ _.fusionGetAttributes( tabsShortcode ) }}}>
		<# if ( autoplayControls ) { #>
		<div class="awb-tabs-autoplay-controls"><button type="button" class="awb-tabs-autoplay-toggle"><span class="awb-tabs-autoplay-toggle-icon" aria-hidden="true"></span><span class="awb-tabs-autoplay-toggle-label awb-tabs-autoplay-toggle-label-pause"><?php esc_html_e( 'Pause', 'fusion-builder' ); ?></span><span class="awb-tabs-autoplay-toggle-label awb-tabs-autoplay-toggle-label-play"><?php esc_html_e( 'Play', 'fusion-builder' ); ?></span></button></div>
		<# } #>
		<div class="nav">
			<ul class="nav-tabs {{ justifiedClass }} fusion-child-element">
			</ul>
		</div>
		<div class="tab-content fusion-child-contents-{{ cid }}"></div>
	</div>
</script>

<script type="text/html" id="tmpl-fusion_tab-shortcode">
<#
var titleTag   = values.title_tag;
var title = 'undefined' === typeof values.title || null === values.title ? '' : values.title;
var icon   = '';
var itemContent = FusionPageBuilderApp.renderContent( values.element_content, cid, false );

if ( usingDynamicParent ) {
			title = '<?php esc_html_e( 'Tab Title', 'fusion-builder' ); ?>';
			itemContent = '<?php esc_html_e( 'This tab use dynamic data.  For a preview please check the front-end.', 'fusion-builder' ); ?>';
}

if ( 'none' !== values.icon ) {
	icon = '<i ' + _.fusionGetAttributes( tabsShortcodeIcon ) + '></i>';
}

// A horizontal tab row cannot grow one tab without going ragged, so the
// description opens the panel there and sits inside the tab when vertical.
var isVertical  = 'vertical' === parentValues.layout;
var description = '';
if ( values.description && '' !== values.description.trim() ) {
	description = '<div class="awb-tab-description"><div class="awb-tab-description-inner">' + values.description + '</div></div>';
}

var tab_nav = '<a ' + _.fusionGetAttributes( tabsShortcodeLink ) + '><' + titleTag + ' class="fusion-tab-heading">';
if ( 'right' === parentValues.icon_position ) {
	tab_nav +=  title + icon;
} else {
	tab_nav += icon + title;
}
tab_nav += '</' + titleTag + '>' + ( isVertical ? description : '' ) + '</a>';
html = tab_nav;

// Change ID for mobile to ensure no duplicate ID.
tab_nav = tab_nav.replace( 'id="fusion-tab-', 'id="mobile-fusion-tab-' );
var tabNavContents  = 'accordion' === values.mobile_mode || 'toggle' === values.mobile_mode ? '<div class="nav fusion-mobile-tab-nav fusion-mobile-extra-' + cid + '"><ul class="nav-tabs ' + justifiedClass + '"><li>' + tab_nav + '</li></ul></div>' : '';
// Transitions animate an inner wrapper so the panel frame stays put. Not
// rendered when there is no transition, to leave that markup untouched.
var paneInner = ( isVertical ? '' : description ) + itemContent;
if ( 'none' !== parentValues.content_transition ) {
	paneInner = '<div class="awb-tab-pane-inner">' + paneInner + '</div>';
}
var tabContents     = '<div ' + _.fusionGetAttributes( tabsShortcodeTab ) + '>' + paneInner + '</div>';

var contentsEl = '.fusion-child-contents-' + parentModel.attributes.cid;

var liSelectors = {};

var thisModel = FusionPageBuilderElements.find( function( model ) {
	return model.get( 'cid' ) == cid;
} );

thisModel = parentModel.children.models.find( function( model ) {
	return model.get( 'cid' ) == cid;
} );

// contents and existing are paired by index for both the initial append and
// later replacements, so a new block would need an entry in both or it is
// silently dropped. The description rides inside tabContents to avoid that.
var extraAppend = {
	selector : contentsEl,
	contents : [ tabNavContents, tabContents ],
	existing : [ '.fusion-mobile-extra-' + cid, '.fusion-extra-' + cid ],
	trigger  : '#' + tabsShortcodeLink.id
}
thisModel.set( 'extraAppend', extraAppend );
thisModel.set( 'selectors', liSelectors );
#>
{{{ html }}}
</script>
