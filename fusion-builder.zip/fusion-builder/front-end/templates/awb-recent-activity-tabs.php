<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.16
 */

?>
<script type="text/html" id="tmpl-awb_recent_activity_tabs-shortcode">
	<#
		var tabSlugs = { popular_posts: 'popular', recent_posts: 'recent', comments: 'comments' },
			isActive = true,
			tabs     = _.filter( ( values.tabs_showing || '' ).split( ',' ), function( tab ) {
				return 'undefined' !== typeof tabSlugs[ tab ];
			} );
	#>
	<# if ( tabs.length ) { #>
		<div {{{ _.fusionGetAttributes( attr ) }}}>
			<div class="awb-rec-tabs__nav">
			<nav class="awb-rec-tabs__tabs" role="tablist">
				<# _.each( tabs, function( tab ) {
					var slug  = tabSlugs[ tab ],
						label = values[ slug + '_label' ] ? values[ slug + '_label' ] : extras[ slug + '_string' ],
						icon  = values[ slug + '_icon' ];
				#>
					<button id="awb-rec-tabs__btn-{{ slug }}-{{ cid }}" class="awb-rec-tabs__tab<# if ( isActive ) { #> awb-rec-tabs__tab--active<# } #>" data-link="awb-rec-tabs__{{ slug }}" role="tab" aria-selected="{{ isActive ? 'true' : 'false' }}" aria-controls="awb-rec-tabs__{{ slug }}-{{ cid }}" tabindex="{{ isActive ? '0' : '-1' }}"><# if ( icon ) { #><span class="awb-rec-tabs__icon {{ _.fusionFontAwesome( icon ) }}" aria-hidden="true"></span><# } #><span class="awb-rec-tabs__label">{{ label }}</span></button>
					<# isActive = false; #>
				<# } ); #>
			</nav>
			</div>

			<# isActive = true; #>
			<div class="awb-rec-tabs__content-tabs">
				<# _.each( tabs, function( tab ) { var slug = tabSlugs[ tab ]; #>
					<div id="awb-rec-tabs__{{ slug }}-{{ cid }}" class="awb-rec-tabs__content<# if ( isActive ) { #> awb-rec-tabs__content--active<# } #><# if ( 'comments' === tab ) { #> awb-rec-tabs__content--comments<# } #>" data-name="awb-rec-tabs__{{ slug }}" role="tabpanel" aria-labelledby="awb-rec-tabs__btn-{{ slug }}-{{ cid }}">
						{{{ output[ slug + '_html' ] }}}
					</div>
					<# isActive = false; #>
				<# } ); #>
			</div>
		</div>
	<# } #>
</script>
