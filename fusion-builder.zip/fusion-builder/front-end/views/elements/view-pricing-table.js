/* eslint no-shadow: 0 */
var FusionPageBuilder = FusionPageBuilder || {};

( function() {

	jQuery( document ).ready( function() {

		// Pricing table stylesiew
		FusionPageBuilder.fusion_pricing_table = FusionPageBuilder.ParentElementView.extend( {

			onInit: function() {
				var params = this.model.get( 'params' );
				if ( 'undefined' === typeof params.background_color_hover && 'undefined' !== typeof params.bordercolor && '' !== params.bordercolor ) {
					params.background_color_hover = params.bordercolor;
				}

				// Reordering changes column positions, so the connected-frame classes must be
				// recomputed. A drag triggers 'sort' on the children collection; add/remove/clone
				// are covered by their childView* hooks below.
				if ( this.model.children ) {
					this.listenTo( this.model.children, 'sort', this.updateColumnWidths );
				}
			},

			beforeGenerateShortcode: function() {
				this.updateElementContent();
			},

			// Children are generated after the template has rendered, so the column count needs a refresh.
			onRender: function() {
				this.updateColumnWidths();
			},

			childViewAdded: function() {
				this.updateColumnWidths();
			},

			childViewRemoved: function() {
				this.updateColumnWidths();
			},

			childViewCloned: function() {
				this.updateColumnWidths();
			},

			updateColumnWidths: function() {
				var columns = 'undefined' !== typeof this.model.children ? this.model.children.length : 0,
					values,
					attr;

				// Update classes on parent.
				values = jQuery.extend( true, {}, window.fusionAllElements[ this.model.get( 'element_type' ) ].defaults, _.fusionCleanParameters( this.model.get( 'params' ) ) );
				attr   = this.computeTableData( values );
				this.$el.find( '.fusion-child-element' ).attr( 'class', attr[ 'class' ] ).attr( 'style', attr.style );

				// Update classes on each child. A just-added child can be in the collection
				// before its view exists; skip it - it rebuilds its own wrapper on first render.
				this.model.children.each( function( child ) {
					var cid    = child.attributes.cid,
						view   = window.FusionPageBuilderViewManager.getView( cid ),
						values;

					if ( 'undefined' === typeof view || ! view.model ) {
						return;
					}

					values = jQuery.extend( true, {}, window.fusionAllElements[ view.model.get( 'element_type' ) ].defaults, _.fusionCleanParameters( view.model.get( 'params' ) ) );

					view.buildColumnWrapperAttr( values, columns );
					view.onRender();
				} );

			},

			/**
			 * Modify template attributes.
			 *
			 * @since 2.0
			 * @param {Object} atts - The attributes.
			 * @return {Object}
			 */
			filterTemplateAtts: function( atts ) {
				// Validate values.
				this.validateValues( atts.values );

				return {
					tableData: this.computeTableData( atts.values )
				};
			},

			/**
			 * Modifies values.
			 *
			 * @since 3.8
			 * @param {Object} values - The values.
			 * @return {void}
			 */
			validateValues: function( values ) {
				values.margin_bottom = _.fusionValidateAttrValue( values.margin_bottom, 'px' );
				values.margin_left   = _.fusionValidateAttrValue( values.margin_left, 'px' );
				values.margin_right  = _.fusionValidateAttrValue( values.margin_right, 'px' );
				values.margin_top    = _.fusionValidateAttrValue( values.margin_top, 'px' );
			},

			/**
			 * Checks if any child column has a top badge.
			 *
			 * @since 3.16
			 * @param {Object} values - The values.
			 * @return {boolean}
			 */
			hasTopBadge: function( values ) {
				var hasBadge      = false,
					badgePosition = 'undefined' !== typeof values.badge_position && '' !== values.badge_position ? values.badge_position : 'top';

				if ( 'top' !== badgePosition ) {
					return false;
				}

				if ( 'undefined' !== typeof this.model.children ) {
					this.model.children.each( function( child ) {
						var params = child.get( 'params' );
						if ( params && 'undefined' !== typeof params.badge_text && '' !== params.badge_text ) {
							hasBadge = true;
						}
					} );
				}

				return hasBadge;
			},

			/**
			 * Builds the data for the table.
			 *
			 * @since 2.0
			 * @param {Object} values - The values.
			 * @return {Object}
			 */
			computeTableData: function( values ) {
				var type      = 'sep',
					cid       = this.model.get( 'cid' ),
					tableData = {
						class: '',
						style: ''
					};

				this.values = values;

				if ( '1' == values.type ) {
					type = 'full';
				}

				tableData[ 'class' ] = 'fusion-child-element awb-pricing-table fusion-pricing-table pricing-table-cid' + cid + ' ' + type + '-boxed-pricing';

				if ( 'stretch' === values.column_alignment ) {
					tableData[ 'class' ] += ' awb-pricing-table--equal-heights';
				}

				if ( 'below_price' === values.cta_position ) {
					tableData[ 'class' ] += ' awb-pricing-table--footer-after-price';
				}

				if ( '' !== values.column_max_width || '' !== values.column_max_width_medium || '' !== values.column_max_width_small ) {
					tableData[ 'class' ] += ' awb-pricing-table--has-max-width';
				}

				// Preserve the column gap next to an expanded standout instead of letting it overlap.
				if ( 'yes' === values.preserve_standout_gap ) {
					tableData[ 'class' ] += ' awb-pricing-table--preserve-standout-gap';
				}

				// Effective columns-per-row per breakpoint; the connected frame reads these in
				// CSS (via :nth-child) to round each row's edge columns.
				var counts = this.resolveResponsiveColumns( values ),
					childCount = 'undefined' !== typeof this.model.children ? this.model.children.length : 1;
				tableData[ 'class' ] += ' awb-pricing-table--columns-' + counts.desktop;
				tableData[ 'class' ] += ' awb-pricing-table--columns-medium-' + counts.medium;
				tableData[ 'class' ] += ' awb-pricing-table--columns-small-' + counts.small;

				// More columns than fit a row means the table wraps into separate bars at that breakpoint.
				if ( childCount > counts.desktop ) {
					tableData[ 'class' ] += ' awb-pricing-table--wrapped';
				}
				if ( childCount > counts.medium ) {
					tableData[ 'class' ] += ' awb-pricing-table--wrapped-medium';
				}
				if ( childCount > counts.small ) {
					tableData[ 'class' ] += ' awb-pricing-table--wrapped-small';
				}

				if ( this.hasTopBadge( values ) ) {
					tableData[ 'class' ] += ' awb-pricing-table--has-top-badge';
				}

				if ( 'yes' === values.price_above_strikethrough ) {
					tableData[ 'class' ] += ' awb-pricing-table--strike-price-above';
				}

				if ( 'yes' === values.price_below_strikethrough ) {
					tableData[ 'class' ] += ' awb-pricing-table--strike-price-below';
				}

				if ( 'yes' === values.features_excluded_strikethrough ) {
					tableData[ 'class' ] += ' awb-pricing-table--strike-excluded';
				}

				tableData[ 'data-empty' ] = this.emptyPlaceholderText;

				tableData = _.fusionVisibilityAtts( values.hide_on_mobile, tableData );

				if ( 'undefined' !== typeof values[ 'class' ] && '' !== values[ 'class' ] ) {
					tableData[ 'class' ] += ' ' + values[ 'class' ];
				}

				if ( '' !== values.margin_top ) {
					tableData.style += 'margin-top:' + values.margin_top + ';';
				}

				if ( '' !== values.margin_right ) {
					tableData.style += 'margin-right:' + values.margin_right + ';';
				}

				if ( '' !== values.margin_bottom ) {
					tableData.style += 'margin-bottom:' + values.margin_bottom + ';';
				}

				if ( '' !== values.margin_left ) {
					tableData.style += 'margin-left:' + values.margin_left + ';';
				}

				tableData.style += this.getStyleVariables( values );

				if (  'undefined' !== typeof values.id && '' !== values.id ) {
					tableData.id = values.id;
				}

				return tableData;
			},

			/**
			 * Resolves the desktop column count, 0 fits all columns into one row.
			 *
			 * @since 3.16
			 * @param {Object} values - The values.
			 * @return {number}
			 */
			resolveColumns: function( values ) {
				var columns = parseInt( values.columns, 10 ) || 0;

				if ( 0 >= columns ) {
					columns = 'undefined' !== typeof this.model.children ? this.model.children.length : 1;
				}

				return Math.min( Math.max( columns, 1 ), 6 );
			},

			/**
			 * Resolves the effective columns-per-row for each breakpoint (-1 inherit,
			 * 0 automatic). Mirrors the PHP get_responsive_column_counts.
			 *
			 * @since 3.16
			 * @param {Object} values - The values.
			 * @return {Object} { desktop, medium, small }, each clamped to 1..6.
			 */
			resolveResponsiveColumns: function( values ) {
				var desktop = this.resolveColumns( values ),
					medium  = parseInt( values.columns_medium, 10 ) || 0,
					small   = parseInt( values.columns_small, 10 ) || 0;

				if ( -1 === medium ) {
					medium = desktop;
				} else if ( 0 === medium ) {
					medium = 6 <= desktop ? 3 : 2;
				} else {
					medium = Math.min( medium, 6 );
				}

				if ( -1 === small ) {
					small = medium;
				} else if ( 0 === small ) {
					small = 6 <= desktop ? 2 : 1;
				} else {
					small = Math.min( small, 6 );
				}

				return { desktop: Math.max( 1, desktop ), medium: Math.max( 1, medium ), small: Math.max( 1, small ) };
			},

			/**
			 * Gets style variables.
			 *
			 * @since 3.16
			 * @param {Object} values - The values.
			 * @return {String}
			 */
			getStyleVariables: function( values ) {
				var headingColor  = '1' == values.type ? values.heading_color_style_1 : values.heading_color_style_2,
					counts        = this.resolveResponsiveColumns( values ),
					columns       = counts.desktop,
					mediumColumns = counts.medium,
					smallColumns  = counts.small,
					customVars    = {},
					cssVarsOptions,
					styles;

				// Legacy options, always output to replicate the former per-instance style block.
				customVars.columns            = columns;
				customVars.bg                 = values.backgroundcolor;
				customVars[ 'bg-hover' ]      = values.background_color_hover;
				customVars[ 'table-bg' ]      = values.bordercolor;
				customVars[ 'divider-color' ] = values.dividercolor;
				customVars[ 'heading-color' ] = headingColor;
				customVars[ 'price-color' ]   = values.pricing_color;
				customVars[ 'body-color' ]    = values.body_text_color;

				cssVarsOptions = [
					'columns_alignment',
					'inner_border_color',
					'badge_bg_color',
					'badge_text_color',
					'badge_line_height',
					'badge_text_transform',
					'price_above_color',
					'price_above_bg_color',
					'price_below_color',
					'price_below_bg_color',
					'heading_bg_color',
					'pricing_bg_color',
					'cta_bg_color',
					'features_alignment',
					'features_icon_color',
					'features_excluded_icon_color',
					'features_stripe_color',
					'currency_color',
					'time_color',
					'body_text_hover_color',
					'sub_heading_color',
					'description_color',
					'sub_heading_line_height',
					'sub_heading_text_transform',
					'description_line_height',
					'description_text_transform',
					'price_above_line_height',
					'price_above_text_transform',
					'price_line_height',
					'price_text_transform',
					'price_below_line_height',
					'price_below_text_transform',
					'features_line_height',
					'features_text_transform'
				];

				cssVarsOptions.column_gap                 = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.column_gap_medium          = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.column_gap_small           = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.row_gap                    = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.row_gap_medium             = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.row_gap_small              = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.column_max_width           = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.column_max_width_medium    = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.column_max_width_small     = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.badge_font_size            = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.badge_letter_spacing       = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.border_size                = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.inner_border_size          = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.badge_padding_top          = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.badge_padding_right        = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.badge_padding_bottom       = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.badge_padding_left         = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.sub_heading_font_size      = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.sub_heading_letter_spacing = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.description_font_size      = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.description_letter_spacing = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.price_font_size            = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.price_letter_spacing       = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.currency_font_size         = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.time_font_size             = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.price_above_font_size      = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.price_above_letter_spacing = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.price_above_border_radius  = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.price_below_font_size      = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.price_below_letter_spacing = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.price_below_border_radius  = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.features_padding_top       = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.features_padding_right     = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.features_padding_bottom    = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.features_padding_left      = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.heading_padding_top        = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.heading_padding_right      = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.heading_padding_bottom     = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.heading_padding_left       = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.pricing_padding_top        = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.pricing_padding_right      = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.pricing_padding_bottom     = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.pricing_padding_left       = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.cta_padding_top            = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.cta_padding_right          = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.cta_padding_bottom         = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.cta_padding_left           = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.features_font_size         = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.features_letter_spacing    = { 'callback': _.fusionGetValueWithUnit };

				// Connected columns sit flush, so never emit a gap - not even a leftover from a previous separated config.
				if ( '1' === values.type ) {
					delete cssVarsOptions.column_gap;
					delete cssVarsOptions.column_gap_medium;
					delete cssVarsOptions.column_gap_small;
					delete cssVarsOptions.row_gap;
					delete cssVarsOptions.row_gap_medium;
					delete cssVarsOptions.row_gap_small;
				}

				styles  = this.getCustomCssVars( customVars );
				styles += this.getCssVarsForOptions( cssVarsOptions );

				if ( 1 !== mediumColumns ) {
					styles += '--awb-columns-medium:' + mediumColumns + ';';
				}

				if ( 1 !== smallColumns ) {
					styles += '--awb-columns-small:' + smallColumns + ';';
				}

				// Top is the CSS default and stretch is class-based, so only center and bottom emit the var.
				if ( 'center' === values.column_alignment ) {
					styles += '--awb-column-alignment:center;';
				} else if ( 'bottom' === values.column_alignment ) {
					styles += '--awb-column-alignment:end;';
				}

				// An explicitly set features background takes precedence over the base hover color.
				if ( '' !== values.backgroundcolor && window.fusionAllElements[ this.model.get( 'element_type' ) ].defaults.backgroundcolor !== values.backgroundcolor ) {
					styles += '--awb-features-bg:' + values.backgroundcolor + ';';
				}

				// Tag-resolved bridge var, so the standout text scale can multiply the heading size.
				if ( -1 === [ 'div', 'p' ].indexOf( this.getTitleTag( values ) ) ) {
					styles += '--awb-title-font-size:var(--' + this.getTitleTag( values ) + '_typography-font-size);';
				}
				styles += this.getBorderRadiusVars( values );
				styles += _.awbGetBoxShadowCssVar( '--awb-box-shadow', values );
				styles += this.getFontStylingVars( 'badge_font', values );
				styles += this.getFontStylingVars( 'sub_heading_font', values );
				styles += this.getFontStylingVars( 'description_font', values );
				styles += this.getFontStylingVars( 'price_above_font', values );
				styles += this.getFontStylingVars( 'price_font', values );
				styles += this.getFontStylingVars( 'price_below_font', values );
				styles += this.getFontStylingVars( 'features_font', values );
				styles += this.getTitleHeadingFontVars( values );

				return styles;
			},

			/**
			 * Gets the HTML tag used for the column titles.
			 *
			 * @since 3.16
			 * @param {Object} values - The values.
			 * @return {String}
			 */
			getTitleTag: function( values ) {
				var headingSize = 'undefined' !== typeof values.heading_size && '' !== values.heading_size ? values.heading_size : '3';

				if ( 'div' === headingSize || 'p' === headingSize ) {
					return headingSize;
				}

				headingSize = parseInt( headingSize, 10 );

				return 'h' + ( 0 < headingSize && 7 > headingSize ? headingSize : 3 );
			},

			/**
			 * Gets the heading typography var overrides for the column titles.
			 *
			 * @since 3.16
			 * @param {Object} values - The values.
			 * @return {String}
			 */
			getTitleHeadingFontVars: function( values ) {
				var titleTypography = _.fusionGetFontStyle( 'title_font', values, 'object' ),
					fontVarArgs;

				fontVarArgs = {
					'font-family': ( titleTypography[ 'font-family' ] ? titleTypography[ 'font-family' ] : '' ),
					'font-weight': ( titleTypography[ 'font-weight' ] ? titleTypography[ 'font-weight' ] : '' ),
					'font-style': ( titleTypography[ 'font-style' ] ? titleTypography[ 'font-style' ] : '' ),
					'font-size': _.fusionGetValueWithUnit( values.title_font_size ),
					'letter-spacing': _.fusionGetValueWithUnit( values.title_letter_spacing ),
					'line-height': values.title_line_height,
					'text-transform': values.title_text_transform
				};

				return this.getHeadingFontVars( this.getTitleTag( values ), fontVarArgs );
			}

		} );
	} );
}( jQuery ) );
