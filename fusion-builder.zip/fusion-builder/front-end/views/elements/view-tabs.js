var FusionPageBuilder = FusionPageBuilder || {};

( function() {

	jQuery( document ).ready( function() {

		// Tabs View.
		FusionPageBuilder.fusion_tabs = FusionPageBuilder.ParentElementView.extend( {

			/**
			 * Runs during render() call.
			 *
			 * @since 2.0
			 * @return {void}
			 */
			onRender: function() {
				var $this = this;

				jQuery( window ).on( 'load', function() {
					$this._refreshJs();
				} );
			},

			/**
			 * Runs after view DOM is patched.
			 *
			 * @since 2.0
			 * @return {void}
			 */
			afterPatch: function() {
				var self     = this,
					children = window.FusionPageBuilderViewManager.getChildViews( this.model.get( 'cid' ) );

				this.appendChildren( '.nav-tabs' );

				_.each( children, function( child ) {
					self.appendContents( child );
				} );

				this._refreshJs();

				this.replayAutoplayIndicator();
			},

			/**
			 * Mirrors the open state onto the mobile accordion / toggle headers.
			 *
			 * Those headers get their active class from PHP and the tab script,
			 * neither of which applies in the editor, so below the tabs breakpoint
			 * the rotation indicator would have nothing to draw on.
			 *
			 * @since 7.16
			 * @return {void}
			 */
			syncMobileNavActive: function() {
				this.$el.find( '.fusion-mobile-tab-nav' ).each( function() {
					const $nav = jQuery( this );

					$nav.find( '.nav-tabs > li' ).toggleClass( 'active', $nav.next( '.tab-pane' ).hasClass( 'active' ) );
				} );
			},

			/**
			 * Patching rebuilds the wrapper class list from the template, dropping
			 * the running class the front end script adds, so without this a
			 * rotation option change gives no feedback in the editor.
			 *
			 * @since 7.16
			 * @return {void}
			 */
			replayAutoplayIndicator: function() {
				const tabs = this.$el.find( '.fusion-tabs' )[ 0 ];

				if ( ! tabs || ! tabs.classList.contains( 'awb-tabs-autoplay' ) ) {
					return;
				}

				tabs.classList.remove( 'awb-tabs-autoplay-running' );
				tabs.getBoundingClientRect(); // Flush styles, so the animation really does start over.
				tabs.classList.add( 'awb-tabs-autoplay-running' );
			},

			refreshJs: function() {
				jQuery( '#fb-preview' )[ 0 ].contentWindow.jQuery( 'body' ).trigger( 'fusion-element-render-fusion_tabs', this.model.attributes.cid );

				this.checkActiveTab();
			},

			/**
			 * Find the active tab.
			 *
			 * @since 2.0
			 * @return {void}
			 */
			getActiveTab: function() {
				var self     = this,
					children = window.FusionPageBuilderViewManager.getChildViews( this.model.get( 'cid' ) );

				_.each( children, function( child ) {
					if ( child.$el.hasClass( 'active' ) ) {
						self.model.set( 'activeTab', child.model.get( 'cid' ) );
					}
				} );
			},

			/**
			 * Set tab as active.
			 *
			 * @since 2.0
			 * @return {void}
			 */
			checkActiveTab: function() {
				var self = this,
					children = window.FusionPageBuilderViewManager.getChildViews( this.model.get( 'cid' ) ),
					activeTab = this.model.get( 'activeTab' ) || self.$el.find( '.nav-tabs li.active' ).data( 'cid' ),
					isKnown = false;

				// Cloning deep copies the model, so the copy points at a tab that only
				// exists in the original; removing the open tab leaves the same dangling
				// reference. An unknown tab has to fall back to the first one.
				_.each( children, function( child ) {
					if ( String( child.model.get( 'cid' ) ) === String( activeTab ) ) {
						activeTab = child.model.get( 'cid' );
						isKnown   = true;
					}
				} );

				if ( ! isKnown ) {
					activeTab = undefined;

					// Silently, as this only corrects state the render is about to redo anyway.
					this.model.unset( 'activeTab', { silent: true } );
				}

				if ( 'undefined' !== typeof activeTab ) {
					_.each( children, function( child ) {
						child.checkActive( activeTab );
					} );
					self.$el.find( '.fusion-extra-' + activeTab ).addClass( 'active in' );
				} else {
					_.each( children, function( child ) {
						if ( child.isFirstChild() ) {
							const tabPane = self.$el.find( '.fusion-extra-' + child.model.get( 'cid' ) );
							const tabLi = self.$el.find( 'a[href="#' + tabPane.attr( 'id' ) + '"]' ).parent( 'li' );
							tabPane.addClass( 'active in' );
							tabLi.addClass( 'active' );

						}
					} );
				}

				self.syncMobileNavActive();
			},

			/**
			 * Modify template attributes.
			 *
			 * @since 2.0
			 * @param {Object} atts - The attributes.
			 * @return {Object} - Returns the attributes.
			 */
			filterTemplateAtts: function( atts ) {
				this.values = atts.values;

				// Create attribute objects.
				atts.tabsShortcode   = this.buildTabsShortcodeAttrs( atts.values );
				atts.justifiedClass  = this.setJustifiedClass( atts.values );

				this.model.set( 'first', true );


				atts.cid             = this.model.get( 'cid' );
				atts.autoplayControls = 'off' !== this.getAutoplayMode( atts.values ) && 'yes' === atts.values.autoplay_pause_button;

				return atts;
			},

			/**
			 * Builds attributes.
			 *
			 * @since 2.0
			 * @param {Object} values - The values.
			 * @return {Object} - Returns the shortcode object.
			 */
			buildTabsShortcodeAttrs: function( values ) {

				// TabsShortcode  Attributes.
				var tabsShortcode = _.fusionVisibilityAtts( values.hide_on_mobile, {
					class: 'fusion-tabs fusion-tabs-cid' + this.model.get( 'cid' ) + ' ' + values.design,
					style: '',
					'aria-orientation': values.layout
				} );

				if ( 'yes' !== values.justified && 'vertical' !== values.layout ) {
					tabsShortcode[ 'class' ] += ' nav-not-justified';
				}

				if ( 'yes' === values.justified && 'vertical' !== values.layout ) {
					tabsShortcode[ 'class' ] += ' nav-is-justified';
				}

				if ( '' !== values.icon_position ) {
					tabsShortcode[ 'class' ] += ' icon-position-' + values.icon_position;
				}

				if ( '' !== values[ 'class' ] ) {
					tabsShortcode[ 'class' ] += ' ' + values[ 'class' ];
				}

				if ( '' !== values.mobile_mode ) {
					tabsShortcode[ 'class' ] += ' mobile-mode-' + values.mobile_mode;
				}

				if ( 'carousel' === values.mobile_mode && 'yes' === values.mobile_sticky_tabs ) {
					tabsShortcode[ 'class' ] += ' mobile-sticky-tabs';
				}

				const contentTransition = this.getContentTransition( values );

				if ( 'none' !== contentTransition ) {
					tabsShortcode[ 'class' ] += ' awb-tabs-transition awb-tabs-transition-' + contentTransition;

					if ( 'slide' === contentTransition ) {
						tabsShortcode[ 'class' ] += ' awb-tabs-transition-dir-' + this.getContentTransitionDirection( values );
					}
				}

				const autoplayMode = this.getAutoplayMode( values );

				if ( 'off' !== autoplayMode ) {
					tabsShortcode[ 'class' ] += ' awb-tabs-autoplay';

					// The JS uses these to decide whether the current viewport rotates.
					if ( 'mobile' !== autoplayMode ) {
						tabsShortcode[ 'class' ] += ' awb-tabs-autoplay-desktop';
					}

					if ( 'desktop' !== autoplayMode ) {
						tabsShortcode[ 'class' ] += ' awb-tabs-autoplay-mobile';
					}

					if ( 'yes' === values.autoplay_indicator ) {
						tabsShortcode[ 'class' ] += ' awb-tabs-autoplay-indicator';

						if ( 'line' === this.getAutoplayIndicatorStyle( values ) ) {
							tabsShortcode[ 'class' ] += ' awb-tabs-autoplay-indicator-line';

							// Classic draws its line over the accent border, which is already fixed to one edge.
							if ( 'clean' === values.design ) {
								tabsShortcode[ 'class' ] += ' awb-tabs-autoplay-indicator-pos-' + this.getAutoplayIndicatorPosition( values );
							}
						}
					}

					if ( 'yes' === values.autoplay_pause_on_hover ) {
						tabsShortcode[ 'class' ] += ' awb-tabs-autoplay-pause-on-hover';
					}

					if ( 'yes' === values.autoplay_resume ) {
						tabsShortcode[ 'class' ] += ' awb-tabs-autoplay-resume';
					}

					if ( 'yes' === values.autoplay_pause_button ) {
						tabsShortcode[ 'class' ] += ' awb-tabs-autoplay-has-controls';
					}
				}

				if ( 'yes' === values.update_url ) {
					tabsShortcode[ 'class' ] += ' awb-tabs-update-url';
				}

				if ( this.hasRadius( values, 'title_' ) ) {
					tabsShortcode[ 'class' ] += ' awb-tabs-title-radius';
				}

				if ( this.hasRadius( values, 'content_' ) ) {
					tabsShortcode[ 'class' ] += ' awb-tabs-content-radius';
				}

				tabsShortcode[ 'class' ] += ( 'vertical' === values.layout ) ? ' vertical-tabs' : ' horizontal-tabs';

				if ( 'no' == values.show_tab_titles ) {
					tabsShortcode[ 'class' ] += ' woo-tabs-hide-headings';
				}

				if ( '' !== values.id ) {
					tabsShortcode.id = values.id;
				}

				// Icon color.
				tabsShortcode.style += '' !== values.icon_color ? '--icon-color:' + values.icon_color + ';' : '';

				// Active icon color.
				tabsShortcode.style += '' !== values.active_icon_color ? '--icon-active-color:' + values.active_icon_color + ';' : '';

				tabsShortcode.style += this.getStyleVariables( values );

				return tabsShortcode;
			},


			/**
			 * Resolves where auto rotation is allowed to run. Mirrors
			 * FusionSC_Tabs::get_autoplay_mode().
			 *
			 * @since 7.16
			 * @param {Object} values - The values.
			 * @return {string} - One of 'off', 'desktop', 'mobile' or 'both'.
			 */
			getAutoplayMode: function( values ) {
				// 'yes' and 'no' are the param's original values and still understood.
				if ( 'yes' === values.autoplay ) {
					return 'both';
				}

				return -1 !== [ 'desktop', 'mobile', 'both' ].indexOf( values.autoplay ) ? values.autoplay : 'off';
			},

			/**
			 * Resolves the tab content transition. Mirrors
			 * FusionSC_Tabs::get_content_transition().
			 *
			 * @since 7.16
			 * @param {Object} values - The values.
			 * @return {string} - One of 'none', 'fade', 'slide' or 'zoom'.
			 */
			getContentTransition: function( values ) {
				return -1 !== [ 'none', 'fade', 'slide', 'zoom' ].indexOf( values.content_transition ) ? values.content_transition : 'fade';
			},

			/**
			 * Resolves which way the slide transition travels.
			 *
			 * @since 7.16
			 * @param {Object} values - The values.
			 * @return {string} - One of 'up', 'down', 'left' or 'right'.
			 */
			getContentTransitionDirection: function( values ) {
				return -1 !== [ 'up', 'down', 'left', 'right' ].indexOf( values.content_transition_direction ) ? values.content_transition_direction : 'up';
			},

			/**
			 * Resolves whether the progress is drawn as a line or a background fill.
			 * Mirrors FusionSC_Tabs::get_autoplay_indicator_style().
			 *
			 * Empty means "default": a line on classic, drawn over the accent edge
			 * it already has, and a background fill on clean, which has none.
			 *
			 * @since 7.16
			 * @param {Object} values - The values.
			 * @return {string} - Either 'background' or 'line'.
			 */
			getAutoplayIndicatorStyle: function( values ) {
				if ( -1 !== [ 'background', 'line' ].indexOf( values.autoplay_indicator_style ) ) {
					return values.autoplay_indicator_style;
				}

				return 'classic' === values.design ? 'line' : 'background';
			},

			/**
			 * Resolves which edge the rotation progress line runs along.
			 *
			 * Empty means "default": the leading edge on vertical tabs, the bottom
			 * edge on horizontal ones. Whitelisted as it becomes a class name.
			 *
			 * @since 7.16
			 * @param {Object} values - The values.
			 * @return {string} - One of 'top', 'bottom', 'start' or 'end'.
			 */
			getAutoplayIndicatorPosition: function( values ) {
				if ( -1 !== [ 'top', 'bottom', 'start', 'end' ].indexOf( values.autoplay_indicator_position ) ) {
					return values.autoplay_indicator_position;
				}

				return 'vertical' === values.layout ? 'start' : 'bottom';
			},

			/**
			 * Whether one of the border radius sets is rounded at any corner.
			 *
			 * Rounded corners need corrections that square ones must not get, and
			 * CSS cannot ask whether a radius was set, so each set gets a class.
			 *
			 * @since 7.16
			 * @param {Object} values - The values.
			 * @param {string} prefix - Param name prefix, 'title_' or 'content_'.
			 * @return {boolean}
			 */
			hasRadius: function( values, prefix ) {
				const corners = [ 'top_left', 'top_right', 'bottom_right', 'bottom_left' ];

				return corners.some( function( corner ) {
					// The unit does not matter, only whether it amounts to zero.
					// Anything unparseable counts as no radius, as it does in PHP.
					const value = parseFloat( String( values[ prefix + 'border_radius_' + corner ] || '' ).trim() );

					return ! isNaN( value ) && 0 !== Math.round( value * 1000 );
				} );
			},

			/**
			 * Builds the CSS value for the tab gradient.
			 *
			 * The shared helper only speaks the unprefixed gradient_* names, so the
			 * prefixed tab params are mapped back onto them. The active state reuses
			 * the regular geometry and only overrides the two colors.
			 *
			 * @since 7.16
			 * @param {Object} values - The values.
			 * @param {string} prefix - Param name prefix, currently only 'title_'.
			 * @param {string} state - Empty for the regular state, or 'active'.
			 * @return {string} - A gradient value, or an empty string when unset.
			 */
			getGradientValue: function( values, prefix, state ) {
				const colorPrefix = state ? prefix + state + '_' : prefix;

				return _.getGradientFontString( {
					gradient_start_color: values[ colorPrefix + 'gradient_start_color' ],
					gradient_end_color: values[ colorPrefix + 'gradient_end_color' ],
					gradient_start_position: values[ prefix + 'gradient_start_position' ],
					gradient_end_position: values[ prefix + 'gradient_end_position' ],
					gradient_type: values[ prefix + 'gradient_type' ],
					linear_angle: values[ prefix + 'linear_angle' ],
					radial_direction: values[ prefix + 'radial_direction' ]
				}, true );
			},

			/**
			 * Set class.
			 *
			 * @since 2.0
			 * @param {Object} values - The values.
			 * @return {string} - Returns a string containing the CSS classes.
			 */
			setJustifiedClass: function( values ) {
				var justifiedClass = '';

				if ( 'yes' === values.justified && 'vertical' !== values.layout ) {
					justifiedClass = ' nav-justified';
				}

				return justifiedClass;
			},

			onInit: function() {
				var params = this.model.get( 'params' );

				// Check for newer margin params.  If unset but regular is, copy from there.
				if ( 'object' === typeof params ) {

					// Split border width into 4.
					if ( 'undefined' === typeof params.alignment && 'clean' === params.design ) {
						params.alignment = 'center';
					}

					this.model.set( 'params', params );
				}

				this.listenTo( window.FusionEvents, 'fusion-preview-viewport-update', this.onChangeDevice );

			},
			onChangeDevice() {
				const device = jQuery( '.viewport-indicator span.active' ).data( 'indicate-viewport' );
				const values = this.model.get( 'params' );
				// Hide active toggle content panels from desktop.
				if ( 'toggle' === values.mobile_mode && 'desktop' === device ) {
					const activeId = this.$el.find( '.nav li.active' ).data( 'cid' );

					this.$el.find( '.tab-pane' ).removeClass( 'active in' );
					this.$el.find( '.tab-pane#tabcid' + activeId ).addClass( 'active in' );

					this.$el.find( '.fusion-mobile-tab-nav li' ).removeClass( 'active' );
					this.$el.find( '.fusion-mobile-tab-nav li a[href="#tabcid' + activeId + '"]' ).parent().addClass( 'active' );
				}

				// Crossing the tabs breakpoint swaps which nav carries the indicator.
				this.syncMobileNavActive();
				this.replayAutoplayIndicator();
			},

			/**
			 * Gets style variables.
			 *
			 * @since 3.9
			 * @param {Object} values - The values.
			 * @return {String}
			 */
			getStyleVariables: function( values ) {
				const cssVarsOptions = [
					'alignment',
					'title_text_transform',
					'title_line_height'
				];

				cssVarsOptions.margin_top    = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.margin_right  = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.margin_bottom = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.margin_left   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.margin_top_medium    = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.margin_right_medium  = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.margin_bottom_medium = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.margin_left_medium   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.margin_top_small    = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.margin_right_small  = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.margin_bottom_small = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.margin_left_small   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_border_radius_top_left   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_border_radius_top_right   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_border_radius_bottom_right   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_border_radius_bottom_left   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_border_radius_top_left   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_border_radius_top_right   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_border_radius_bottom_right   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_border_radius_bottom_left   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_padding_top   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_padding_right   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_padding_bottom   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_padding_left   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_padding_top_medium   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_padding_right_medium   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_padding_bottom_medium   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_padding_left_medium   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_padding_top_small   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_padding_right_small   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_padding_bottom_small   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_padding_left_small   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_height   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_height_medium   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.content_height_small   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_padding_top   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_padding_right   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_padding_bottom   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_padding_left   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_padding_top_medium   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_padding_right_medium   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_padding_bottom_medium   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_padding_left_medium   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_padding_top_small   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_padding_right_small   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_padding_bottom_small   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_padding_left_small   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_font_size   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.title_letter_spacing   = { 'callback': _.fusionGetValueWithUnit };

				const customVars = [];

				if ( values.inactivecolor ) {
					customVars.inactive_color = values.inactivecolor;
				}
				if ( values.title_text_color ) {
					customVars.title_text_color = values.title_text_color;
				}
				if ( values.title_active_text_color ) {
					customVars.title_active_text_color = values.title_active_text_color;
				}

				customVars.background_color = values.backgroundcolor;
				customVars.border_color = values.bordercolor;
				customVars.active_border_color = values.active_border_color;

				if ( '' !== values.active_border_size ) {
					customVars.active_border_size = _.fusionGetValueWithUnit( values.active_border_size );
				}

				// Left unset when empty, so the LESS keeps its per layout default.
				if ( '' !== values.title_alignment ) {
					customVars.title_alignment = values.title_alignment;

					// With the icon above the title there is nothing to space apart on that axis.
					customVars.title_alignment_block = 'space-between' === values.title_alignment ? 'center' : values.title_alignment;
				}

				if ( '' !== values.title_min_width ) {
					customVars.title_min_width = _.fusionGetValueWithUnit( values.title_min_width );
				}

				if ( '' !== values.description_font_size ) {
					customVars.description_font_size = _.fusionGetValueWithUnit( values.description_font_size );
				}

				if ( '' !== values.description_color ) {
					customVars.description_color = values.description_color;
				}

				// Left unset when empty, so the LESS keeps its per design fallback.
				if ( '' !== values.content_background_color ) {
					customVars.content_background_color = values.content_background_color;
				}

				// Only emitted once the gradient has colors, so the LESS keeps its
				// own 'none' and the flat colors are left untouched.
				if ( 'yes' === values.title_gradient ) {
					const titleGradient = this.getGradientValue( values, 'title_' );
					if ( '' !== titleGradient ) {
						customVars.title_bg_image = titleGradient;
					}

					// Left unset when the active state has no colors of its own, so
					// the LESS falls back to the regular gradient above.
					const activeGradient = this.getGradientValue( values, 'title_', 'active' );
					if ( '' !== activeGradient ) {
						customVars.title_active_bg_image = activeGradient;
					}

					// The classic accent edge would otherwise cut a flat stripe across the gradient on hover.
					if ( '' !== titleGradient || '' !== activeGradient ) {
						customVars.title_hover_border_color = 'var(--awb-inactive-color)';
					}
				}


				if ( 'none' !== this.getContentTransition( values ) ) {
					customVars.transition_speed = parseInt( values.content_transition_speed, 10 ) + 'ms';
				}

				if ( 'off' !== this.getAutoplayMode( values ) ) {
					customVars.autoplay_speed = parseInt( values.autoplay_speed, 10 ) + 'ms';

					if ( '' !== values.autoplay_indicator_size ) {
						customVars.autoplay_indicator_size = _.fusionGetValueWithUnit( values.autoplay_indicator_size );
					}

					// Left unset when empty, so the LESS falls back to the active border color.
					if ( '' !== values.autoplay_indicator_color ) {
						customVars.autoplay_indicator_color = values.autoplay_indicator_color;

						// The LESS tones the indicator down only because it otherwise
						// borrows the active border color. A deliberate color is used as given.
						customVars.autoplay_indicator_opacity = 1;

						if ( 'classic' === values.design ) {
							customVars.autoplay_track_color = 'var(--awb-active-border-color)';
						}
					}

					// A deliberate track color wins over the classic fallback above.
					if ( '' !== values.autoplay_track_color ) {
						customVars.autoplay_track_color = values.autoplay_track_color;
					}

					// Left unset when empty, so the button keeps following the tab title colors.
					if ( '' !== values.autoplay_pause_button_color ) {
						customVars.autoplay_toggle_color = values.autoplay_pause_button_color;
					}
				}

				// Each side is left unset when empty, so the LESS keeps its own per
				// design default for that side and nothing is emitted for the
				// overwhelming majority of elements.
				if ( 'clean' === values.design ) {
					[ 'title_border_size', 'content_border_size' ].forEach( function( prefix ) {
						[ 'top', 'right', 'bottom', 'left' ].forEach( function( side ) {
							var value = values[ prefix + '_' + side ];

							if ( '' !== value && 'undefined' !== typeof value ) {
								customVars[ prefix + '_' + side ] = _.fusionGetValueWithUnit( value );
							}
						} );
					} );
				} else if ( '' !== values.border_size ) {
					customVars.border_size = _.fusionGetValueWithUnit( values.border_size );
				}

				return this.getCssVarsForOptions( cssVarsOptions ) + this.getCustomCssVars( customVars ) + this.getFontStylingVars( 'title_font', values );
			}

		} );
	} );
}( jQuery ) );
