var FusionPageBuilder = FusionPageBuilder || {};

( function() {

	jQuery( document ).ready( function() {

		FusionPageBuilder.awb_recent_activity_tabs = FusionPageBuilder.ElementView.extend( {

			/**
			 * Modify template attributes.
			 *
			 * @since 3.16
			 * @param {Object} atts - The attributes.
			 * @return {Object}
			 */
			filterTemplateAtts: function( atts ) {
				var attributes = {};

				this.values = atts.values;

				attributes.values = atts.values;
				attributes.extras = atts.extras;
				attributes.cid    = this.model.get( 'cid' );
				attributes.attr   = this.buildAttr( atts.values );
				attributes.output = this.buildOutput( atts );

				return attributes;
			},

			/**
			 * Builds the wrapper attributes.
			 *
			 * @since 3.16
			 * @param {Object} values - The values object.
			 * @return {Object}
			 */
			buildAttr: function( values ) {
				var attr = {
					class: 'awb-rec-tabs awb-rec-tabs-' + this.model.get( 'cid' ),
					style: ''
				};

				attr[ 'class' ] += ' awb-rec-tabs--align-' + values.alignment;

				if ( this.hasIcons( values ) ) {
					attr[ 'class' ] += ' awb-rec-tabs--icon-' + values.icon_position;
				}

				if ( '' !== values.id ) {
					attr.id = values.id;
				}

				if ( '' !== values[ 'class' ] ) {
					attr[ 'class' ] += ' ' + values[ 'class' ];
				}

				attr = _.fusionVisibilityAtts( values.hide_on_mobile, attr );
				attr = _.fusionAnimations( values, attr );

				attr.style += this.getStyleVariables( values );

				return _.awbHTMLAttributes( values, attr );
			},

			/**
			 * Whether any tab has an icon set.
			 *
			 * @since 3.16
			 * @param {Object} values - The values object.
			 * @return {Boolean}
			 */
			hasIcons: function( values ) {
				return '' !== values.popular_icon || '' !== values.recent_icon || '' !== values.comments_icon;
			},

			/**
			 * Builds the per tab markup, which is rendered server side.
			 *
			 * @since 3.16
			 * @param {Object} atts - The atts object.
			 * @return {Object}
			 */
			buildOutput: function( atts ) {
				if ( 'undefined' !== typeof atts.query_data ) {
					return atts.query_data;
				}

				if ( 'undefined' !== typeof atts.markup ) {
					return atts.markup;
				}

				return {};
			},

			/**
			 * Gets the style variables, mirroring get_style_variables() on the PHP side.
			 *
			 * @since 3.16
			 * @param {Object} values - The values object.
			 * @return {String}
			 */
			getStyleVariables: function( values ) {
				var cssVarsOptions = [
						'border_style',
						'separator_style',
						'tab_text_transform',
						'title_text_transform',
						'content_text_transform',
						'date_text_transform',
						'title_color',
						'content_color',
						'date_color',
						'content_lines_clamp',
						'tab_line_height',
						'title_line_height',
						'content_line_height',
						'date_line_height'
					],
					// Global Option backed values are emitted unconditionally, mirroring the PHP side.
					alwaysEmit     = [
						'border_color',
						'tab_bg_color',
						'active_tab_bg_color',
						'hover_tab_bg_color',
						'tab_bar_color',
						'hover_tab_bar_color',
						'active_tab_bar_color',
						'bg_color',
						'separator_color',
						'link_hover_color',
						'date_bg_color',
						'tab_color',
						'hover_tab_color',
						'active_tab_color',
						'icon_color',
						'hover_icon_color',
						'active_icon_color'
					],
					customVars     = {},
					unitOptions    = [
						'margin_top',
						'margin_right',
						'margin_bottom',
						'margin_left',
						'margin_top_medium',
						'margin_right_medium',
						'margin_bottom_medium',
						'margin_left_medium',
						'margin_top_small',
						'margin_right_small',
						'margin_bottom_small',
						'margin_left_small',
						'border_top',
						'border_right',
						'border_bottom',
						'border_left',
						'radius_top_left',
						'radius_top_right',
						'radius_bottom_right',
						'radius_bottom_left',
						'tab_font_size',
						'tab_letter_spacing',
						'tab_padding_top',
						'tab_padding_right',
						'tab_padding_bottom',
						'tab_padding_left',
						'tab_bar_size',
						'separator_size',
						'content_padding_top',
						'content_padding_right',
						'content_padding_bottom',
						'content_padding_left',
						'image_width',
						'date_padding_top',
						'date_padding_right',
						'date_padding_bottom',
						'date_padding_left',
						'image_date_gap',
						'image_date_radius_top_left',
						'image_date_radius_top_right',
						'image_date_radius_bottom_right',
						'image_date_radius_bottom_left',
						'title_font_size',
						'title_letter_spacing',
						'content_font_size',
						'content_letter_spacing',
						'date_font_size',
						'date_letter_spacing'
					],
					fontVars;

				this.values = values;

				_.each( unitOptions, function( option ) {
					cssVarsOptions[ option ] = { callback: _.fusionGetValueWithUnit };
				} );

				_.each( alwaysEmit, function( option ) {
					if ( '' !== values[ option ] && 'undefined' !== typeof values[ option ] ) {
						customVars[ option ] = values[ option ];
					}
				} );

				if ( '' !== values.icon_size && 'undefined' !== typeof values.icon_size ) {
					customVars.icon_size = _.fusionGetValueWithUnit( values.icon_size );
				}

				fontVars = this.getFontStylingVars( 'tab_font', values ) +
					this.getFontStylingVars( 'title_font', values ) +
					this.getFontStylingVars( 'content_font', values ) +
					this.getFontStylingVars( 'date_font', values );

				return this.getCssVarsForOptions( cssVarsOptions ) + this.getCustomCssVars( customVars ) + fontVars;
			}
		} );
	} );
}( jQuery ) );
