var FusionPageBuilder = FusionPageBuilder || {};

( function() {

	jQuery( document ).ready( function() {

		// Testimonials parent View.
		FusionPageBuilder.fusion_testimonials = FusionPageBuilder.ParentElementView.extend( {

			/**
			 * Runs before view DOM is patched.
			 *
			 * @since 3.16
			 * @return {void}
			 */
			beforePatch: function() {

				// Destroy the Swiper instance before creating the new one after patch.
				this.destroyCarousel();
			},

			/**
			 * Runs after view DOM is patched.
			 *
			 * @since 2.0
			 * @return {void}
			 */
			afterPatch: function() {

				// Grid has no Swiper wrapper - children are direct grid cells.
				if ( 'grid' === this.values.layout ) {
					this.appendChildren( '.awb-testimonials-grid' );
					return;
				}

				// Lone testimonial: static container, no Swiper to init.
				if ( this.isSingleStatic( this.values ) ) {
					this.appendChildren( '.reviews' );
					return;
				}

				this.appendChildren( '.swiper-wrapper' );
				this._refreshJs();
			},

			/**
			 * Destroys the Swiper instance so it can be rebuilt after DOM changes.
			 *
			 * @since 3.16
			 * @return {void}
			 */
			destroyCarousel: function() {
				jQuery( this.$el ).find( '.reviews.awb-carousel' ).each( function() {
					if ( this.swiper ) {

						// cleanStyles must stay false: it would strip the inline CSS vars from the carousel + slides.
						this.swiper.destroy( true, false );
					}
				} );
			},

			childViewAdded: function() {
				this.reRender();
			},

			childViewRemoved: function() {
				this.reRender();
			},

			childViewCloned: function() {
				this.reRender();
			},

			/**
			 * Modify template attributes.
			 *
			 * @since 2.0
			 * @param {Object} atts - The attributes.
			 * @return {Object}
			 */
			filterTemplateAtts: function( atts ) {
				var attributes = {};

				this.values = atts.values;

				this.validateValues( atts.values );

				attributes.attr           = this.buildAttr( atts.values );
				attributes.carouselAttr   = this.buildCarouselAttr( atts.values );
				attributes.paginationAttr = this.buildPaginationAttr( atts.values );
				attributes.layout         = atts.values.layout;

				// A lone testimonial renders static (no Swiper) on the fade / carousel layouts (mirrors PHP).
				attributes.useSwiper      = ! ( 'grid' === atts.values.layout || this.isSingleStatic( atts.values ) );

				// Marquee self-scrolls: force navigation off so the template emits no dots / arrows.
				attributes.navigation     = ( 'marquee' === atts.values.layout ) ? 'no' : atts.values.navigation;
				attributes.masked         = ( ( 'carousel' === atts.values.layout || 'marquee' === atts.values.layout ) && 'yes' === atts.values.mask_edges );
				attributes.prevAttr       = this.buildNavIconAttr( atts.values.prev_icon );
				attributes.nextAttr       = this.buildNavIconAttr( atts.values.next_icon );
				attributes.children       = 'undefined' !== typeof atts.values.element_content ? atts.values.element_content.match( /\[fusion_testimonial ((.|\n|\r)*?)\]/g ).length : 1;

				return attributes;
			},

			/**
			 * Modifies the values.
			 *
			 * @since 2.0
			 * @param {Object} values - The values object.
			 * @return {void}
			 */
			validateValues: function( values ) {
				values.random = ( 'yes' === values.random || '1' === values.random ) ? 1 : 0;

				if ( 'clean' === values.design && '' === values.navigation ) {
					values.navigation = 'yes';
				} else if ( 'classic' === values.design && '' === values.navigation ) {
					values.navigation = 'no';
				}

				values.testimonial_border_color = '0' === values.testimonial_border_size ? 'rgba(255,255,255,0)' : values.testimonial_border_color;
			},

			/**
			 * Builds attributes.
			 *
			 * @since 2.0
			 * @param {Object} values - The values object.
			 * @return {Object}
			 */
			buildAttr: function( values ) {
				var attr = _.fusionVisibilityAtts( values.hide_on_mobile, {
					class: 'fusion-testimonials ' + values.design + ' awb-testimonials-layout-' + values.layout + ' awb-testimonial-content-' + values.content_alignment + ' awb-speech-bubble-' + values.testimonial_speech_bubble + ' awb-testimonial-author-' + values.author_layout + ' fusion-testimonials-cid' + this.model.get( 'cid' ) + ' ' + values[ 'class' ],
					style: ''
				} );

				attr.style += this.getStyleVariables( values );

				// Box shadows need overflow room on the swiper layouts (see .awb-testimonials-has-shadow).
				if ( 0 < this.getShadowOverflow( values ) ) {
					attr[ 'class' ] += ' awb-testimonials-has-shadow';
				}

				attr.id = values.id;

				return attr;
			},

			/**
			 * Whether a lone testimonial should render static (no Swiper) - mirrors the PHP single_static rule.
			 *
			 * @since 3.16
			 * @param {Object} values - The values object.
			 * @return {boolean}
			 */
			isSingleStatic: function( values ) {
				var content = values.element_content,
					count;

				if ( 'grid' === values.layout || 'marquee' === values.layout ) {
					return false;
				}

				count = ( 'undefined' !== typeof content && content ) ? ( content.match( /\[fusion_testimonial ((.|\n|\r)*?)\]/g ) || [] ).length : 0;

				return 1 >= count;
			},

			/**
			 * Builds the carousel attributes.
			 *
			 * @since 3.16
			 * @param {Object} values - The values object.
			 * @return {Object}
			 */
			buildCarouselAttr: function( values ) {
				var carouselAttr,
					scrollItems,
					cols;

				// Grid: plain CSS grid container, no Swiper.
				if ( 'grid' === values.layout ) {
					return {
						class: 'reviews awb-testimonials-grid fusion-child-element',
						style: this.getGridStyleVariables( values )
					};
				}

				// Lone testimonial: plain container, no Swiper classes (so it never inits / transitions).
				if ( this.isSingleStatic( values ) ) {
					return {
						class: 'reviews fusion-child-element'
					};
				}

				carouselAttr = {
					class: 'reviews awb-carousel awb-swiper awb-swiper-dots-position-' + values.dots_position
				};

				carouselAttr[ 'data-touchscroll' ]   = 'touch';
				carouselAttr[ 'data-loop' ]          = values.loop;
				carouselAttr[ 'data-pagination' ]    = 'bullets';
				carouselAttr[ 'data-autoplay' ]      = ( 'yes' === values.autoplay && 0 < parseInt( values.speed, 10 ) ) ? 'yes' : 'no';
				carouselAttr[ 'data-autoplayspeed' ] = parseInt( values.speed, 10 );
				carouselAttr[ 'data-autoplaypause' ] = values.autoplay_hover_pause;
				carouselAttr.style                   = this.getNavStyleVariables( values );

				if ( 'carousel' === values.layout || 'marquee' === values.layout ) {
					cols = this.resolveColumns( values );

					// Mask Edges: fade the left / right edges (arrows are hidden while masked).
					if ( 'yes' === values.mask_edges ) {
						carouselAttr[ 'class' ] += ' awb-carousel--masked';
					}

					carouselAttr[ 'data-layout' ]           = values.layout;
					carouselAttr[ 'data-columns' ]          = cols.desktop;
					carouselAttr[ 'data-columnsmedium' ]    = cols.medium;
					carouselAttr[ 'data-columnssmall' ]     = cols.small;
					carouselAttr[ 'data-itemmargin' ]       = '' !== values.column_spacing ? parseInt( values.column_spacing, 10 ) : 30;

					if ( 'marquee' === values.layout ) {

						// Marquee: continuous scroll. Direction + scroll pace (data-speed drives the Swiper transition).
						carouselAttr[ 'data-marquee-direction' ] = values.marquee_direction;
						carouselAttr[ 'data-speed' ]             = parseInt( values.speed, 10 );
					} else {
						scrollItems = Math.max( 1, parseInt( values.scroll_items, 10 ) );
						carouselAttr[ 'data-scrollitems' ]        = scrollItems;
						carouselAttr[ 'data-scrollitems-medium' ] = scrollItems;
						carouselAttr[ 'data-scrollitems-small' ]  = scrollItems;
					}
				} else {
					carouselAttr[ 'data-slide-effect' ] = 'fade';
					carouselAttr[ 'data-itemmargin' ]   = '0';
				}

				return carouselAttr;
			},

			/**
			 * Builds nav icon attributes.
			 *
			 * @since 3.16
			 * @param {String} value - The value.
			 * @return {Object}
			 */
			buildNavIconAttr: function( value ) {
				var icon = {
					class: _.fusionFontAwesome( value ),
					'aria-hidden': 'true'
				};

				return icon;
			},

			/**
			 * Gets the grid layout style variables.
			 *
			 * @since 3.16
			 * @param {Object} values - The values.
			 * @return {String}
			 */
			getGridStyleVariables: function( values ) {
				var cols   = this.resolveColumns( values ),
					styles = '--awb-columns:' + cols.desktop + ';';

				if ( 1 !== cols.medium ) {
					styles += '--awb-columns-medium:' + cols.medium + ';';
				}

				if ( 1 !== cols.small ) {
					styles += '--awb-columns-small:' + cols.small + ';';
				}

				if ( '' !== values.column_spacing ) {
					styles += '--awb-column-spacing:' + _.fusionGetValueWithUnit( values.column_spacing ) + ';';
				}

				if ( '' !== values.column_spacing_medium ) {
					styles += '--awb-column-spacing-medium:' + _.fusionGetValueWithUnit( values.column_spacing_medium ) + ';';
				}

				if ( '' !== values.column_spacing_small ) {
					styles += '--awb-column-spacing-small:' + _.fusionGetValueWithUnit( values.column_spacing_small ) + ';';
				}

				return styles;
			},

			/**
			 * Resolve the responsive column counts (mirrors the PHP resolve_columns()).
			 *
			 * @since 3.16
			 * @param {Object} values - The values.
			 * @return {Object} { desktop, medium, small }
			 */
			resolveColumns: function( values ) {
				var childCount = 0,
					desktop    = parseInt( values.columns, 10 ),
					medium     = parseInt( values.columns_medium, 10 ),
					small      = parseInt( values.columns_small, 10 ),
					matches;

				if ( 'undefined' !== typeof values.element_content ) {
					matches    = values.element_content.match( /\[fusion_testimonial[\s/\]]/g );
					childCount = matches ? matches.length : 0;
				}

				if ( isNaN( desktop ) || 1 > desktop ) {
					desktop = 0 < childCount ? Math.min( childCount, 6 ) : 1;
				} else {
					desktop = Math.min( desktop, 6 );
				}

				if ( -1 === medium ) {
					medium = desktop;
				} else if ( 0 === medium ) {
					medium = 6 <= desktop ? 3 : 2;
				} else {
					medium = Math.min( medium, 6 );
				}

				if ( -1 === small ) {
					small = medium;
				} else if ( 0 === small ) {
					small = 6 <= desktop ? 2 : 1;
				} else {
					small = Math.min( small, 6 );
				}

				return { desktop: desktop, medium: medium, small: small };
			},

			/**
			 * Gets the navigation (arrows / dots) style variables for the carousel element.
			 *
			 * @since 3.16
			 * @param {Object} values - The values.
			 * @return {String}
			 */
			getNavStyleVariables: function( values ) {
				const cssVarsOptions = [
						'arrow_bgcolor',
						'arrow_color',
						'arrow_hover_bgcolor',
						'arrow_hover_color',
						'dots_active_color',
						'dots_align'
					],
					cssCustomVars = [];

				this.values = values;

				cssVarsOptions.arrow_box_width                  = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.arrow_box_height                 = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.arrow_size                       = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.arrow_position_horizontal        = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.arrow_position_vertical          = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.arrow_border_radius_top_left     = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.arrow_border_radius_top_right    = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.arrow_border_radius_bottom_right = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.arrow_border_radius_bottom_left  = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.dots_spacing                     = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.dots_margin_top                  = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.dots_margin_bottom               = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.dots_active_size                 = { 'callback': _.fusionGetValueWithUnit };

				if ( values.arrow_position_vertical && '' !== values.arrow_position_vertical ) {
					cssCustomVars.arrow_position_vertical_transform = 'none';
				}

				return this.getCssVarsForOptions( cssVarsOptions ) + this.getCustomCssVars( cssCustomVars );
			},

			/**
			 * Builds attributes.
			 *
			 * @since 2.0
			 * @return {Object}
			 */
			buildPaginationAttr: function() {
				var paginationAttr = {
					class: 'swiper-pagination testimonial-pagination',
					id: 'fusion-testimonials-cid' + this.model.get( 'cid' )
				};
				return paginationAttr;
			},

			/**
			 * Extra room an outer box shadow needs beyond the card so Swiper's overflow does not clip it.
			 *
			 * @since 3.16
			 * @param {Object} values - The values.
			 * @return {number}
			 */
			getShadowOverflow: function( values ) {
				if ( 'yes' !== values.box_shadow || 'inset' === values.box_shadow_style ) {
					return 0;
				}

				var blur   = parseFloat( values.box_shadow_blur ) || 0,
					spread = parseFloat( values.box_shadow_spread ) || 0,
					h      = Math.abs( parseFloat( values.box_shadow_horizontal ) || 0 ),
					v      = Math.abs( parseFloat( values.box_shadow_vertical ) || 0 );

				return Math.max( 0, blur + spread + Math.max( h, v ) );
			},

			/**
			 * The --awb-shadow-overflow CSS var (empty when there is no outer shadow).
			 *
			 * @since 3.16
			 * @param {Object} values - The values.
			 * @return {String}
			 */
			getShadowOverflowVar: function( values ) {
				var reach = this.getShadowOverflow( values );
				return 0 < reach ? '--awb-shadow-overflow:' + reach + 'px;' : '';
			},

			/**
			 * Gets style variables.
			 *
			 * @since 3.9
			 * @param {Object} values - The values.
			 * @return {String}
			 */
			getStyleVariables: function( values ) {
				const cssVarsOptions = [
						'flex_align_items',
						'backgroundcolor',
						'testimonial_border_style',
						'testimonial_text_line_height',
						'testimonial_text_text_transform',
						'textcolor',
						'name_company_line_height',
						'name_company_text_transform',
						'name_company_text_color',
						'company_line_height',
						'company_text_transform',
						'company_text_color',
						'content_valign',
						'rating_active_color',
						'rating_inactive_color',
						'initials_bg_color',
						'initials_text_color',
						'testimonial_icon_color',
						'navigation_color'
					],
					cssCustomVars = [];

				cssVarsOptions.testimonial_border_top          = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.testimonial_border_right        = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.testimonial_border_bottom       = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.testimonial_border_left         = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.testimonial_border_color        = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.testimonial_text_font_size      = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.testimonial_text_letter_spacing = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.name_company_font_size          = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.name_company_letter_spacing     = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.company_font_size               = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.company_letter_spacing          = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.box_padding_top                = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.box_padding_right              = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.box_padding_bottom             = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.box_padding_left               = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.avatar_gap                      = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.author_block_gap                = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.rating_size                     = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.testimonial_icon_size           = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.triangle_size                   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.navigation_size                 = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.margin_top                      = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.margin_right                    = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.margin_bottom                   = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.margin_left                     = { 'callback': _.fusionGetValueWithUnit };

				cssCustomVars[ 'testimonial-border-width-top' ]    = _.fusionGetValueWithUnit( values.testimonial_border_top );
				cssCustomVars[ 'testimonial-border-width-right' ]  = _.fusionGetValueWithUnit( values.testimonial_border_right );
				cssCustomVars[ 'testimonial-border-width-bottom' ] = _.fusionGetValueWithUnit( values.testimonial_border_bottom );
				cssCustomVars[ 'testimonial-border-width-left' ]   = _.fusionGetValueWithUnit( values.testimonial_border_left );

				// Non-stretch alignment lets cards size to content (see --awb-review-height).
				if ( 'card' === values.design && 'stretch' !== values.flex_align_items ) {
					cssCustomVars[ 'awb-review-height' ] = 'auto';
				}

				// A chosen background-icon color is used at full opacity (the color picker owns the alpha).
				if ( '' !== values.testimonial_icon_color ) {
					cssCustomVars[ 'awb-testimonial-icon-opacity' ] = '1';
				}

				return this.getCssVarsForOptions( cssVarsOptions ) + this.getBorderRadiusVars( values ) + this.getCustomCssVars( cssCustomVars, false ) + _.awbGetBoxShadowCssVar( '--awb-box-shadow', values ) + this.getAuthorLayoutVars( values ) + this.getFontStylingVars( 'testimonial_text_font', values ) + this.getFontStylingVars( 'name_company_font', values ) + this.getFontStylingVars( 'company_font', values ) + this.getShadowOverflowVar( values );
			},

			/**
			 * Gets the card author-parts layout CSS variables (mirrors PHP get_author_layout_vars()).
			 *
			 * @since 3.16
			 * @param {Object} values - The values.
			 * @return {String}
			 */
			getAuthorLayoutVars: function( values ) {
				var align, placement, isColumn, order, direction, cross, justify, vars, sideOrder, gap, hasGap, gapUnit, crossValign;

				if ( 'card' !== values.design ) {
					return '';
				}

				align     = values.content_alignment ? values.content_alignment : 'flex-start';
				placement = values.avatar_placement;
				isColumn  = ( 'above' === placement || 'below' === placement );
				order     = ( 'after' === placement || 'below' === placement ) ? '1' : '0';

				if ( isColumn ) {
					direction = 'column';
					cross     = align;
					justify   = 'flex-start';
				} else {
					direction = 'row';
					cross     = 'center';
					justify   = ( 'space_between' === values.author_distribution ) ? 'space-between' : align;
				}

				vars = '--awb-author-direction:' + direction + ';--awb-avatar-order:' + order + ';--awb-author-cross:' + cross + ';--awb-author-justify:' + justify + ';';

				// Author Block Position + Gap. Left / Right split it beside the quote; Above / Below stack it.
				hasGap  = '' !== values.author_block_gap;
				gapUnit = hasGap ? _.fusionGetValueWithUnit( values.author_block_gap ) : '';

				if ( 'left' === values.author_block_position || 'right' === values.author_block_position ) {
					sideOrder = 'right' === values.author_block_position ? '1' : '-1';
					gap       = hasGap ? gapUnit : '2em';
					crossValign = 'space-between' === values.content_valign ? 'stretch' : values.content_valign;
					vars += '--awb-card-direction:row;--awb-card-cross:' + crossValign + ';--awb-quote-flex:1 1 auto;--awb-card-inner-gap:' + gap + ';';
					vars += '--awb-author-block-order:' + sideOrder + ';--awb-author-block-mt:0;--awb-author-block-mb:0;--awb-author-block-pt:0;';

					if ( '' !== values.split_author_width ) {
						vars += '--awb-author-basis:' + _.fusionGetValueWithUnit( values.split_author_width ) + ';';
					}
				} else if ( 'above' === values.author_block_position ) {
					gap = hasGap ? gapUnit : '1.25em';
					vars += '--awb-author-block-order:-1;--awb-author-block-mt:0;--awb-author-block-mb:' + gap + ';--awb-author-block-pt:0;';
				} else if ( hasGap ) {
					vars += '--awb-author-block-pt:' + gapUnit + ';';
				}

				if ( 'below_quote' === values.rating_position ) {
					vars += '--awb-rating-order:2;';
				} else if ( 'above_author' === values.rating_position || 'below_author' === values.rating_position ) {
					vars += '--awb-rating-author-order:' + ( 'above_author' === values.rating_position ? '-1' : '2' ) + ';';

					if ( 'before' === placement || 'after' === placement ) {
						vars += '--awb-author-wrap:wrap;--awb-rating-basis:100%;';
					}
				}

				return vars;
			}

		} );
	} );
}( jQuery ) );
