var FusionPageBuilder = FusionPageBuilder || {};

( function() {


	jQuery( document ).ready( function() {

		// Woo Rating Component View.
		FusionPageBuilder.fusion_tb_woo_additional_info = FusionPageBuilder.ElementView.extend( {

			/**
			 * Modify template attributes.
			 *
			 * @since 3.2
			 * @param {Object} atts - The attributes.
			 * @return {Object}
			 */
			filterTemplateAtts: function( atts ) {
				var attributes = {};

				// Validate values.
				this.values = atts.values;

				// Any extras that need passed on.
				attributes.cid         = this.model.get( 'cid' );
				attributes.wrapperAttr = this.buildAttr( atts.values );
				attributes.output      = this.buildOutput( atts );

				return attributes;
			},

			/**
			 * Builds attributes.
			 *
			 * @since  3.2
			 * @param  {Object} values - The values object.
			 * @return {Object}
			 */
			buildAttr: function( values ) {
				var attr         = _.fusionVisibilityAtts( values.hide_on_mobile, {
						class: 'fusion-woo-additional-info-tb fusion-woo-additional-info-tb-' + this.model.get( 'cid' ),
						style: ''
					} );

				if ( '' !== values[ 'class' ] ) {
					attr[ 'class' ] += ' ' + values[ 'class' ];
				}

				if ( '' !== values.id ) {
					attr.id = values.id;
				}

				attr.style += this.getStyleVariables( values );

				attr = _.fusionAnimations( values, attr );

				return attr;
			},

			/**
			 * Builds output.
			 *
			 * @since  3.2
			 * @param  {Object} values - The values object.
			 * @return {String}
			 */
			buildOutput: function( atts ) {
				var output = '';

				if ( 'undefined' !== typeof atts.markup && 'undefined' !== typeof atts.markup.output && 'undefined' === typeof atts.query_data ) {
					output = jQuery( jQuery.parseHTML( atts.markup.output ) ).filter( '.fusion-woo-additional-info-tb' ).html();
					output = ( 'undefined' === typeof output ) ? atts.markup.output : output;
				} else if ( 'undefined' !== typeof atts.query_data && 'undefined' !== typeof atts.query_data.woo_additional_info ) {
					output = atts.query_data.woo_additional_info;
				}

				return output;
			},

			/**
			 * Gets style variables.
			 *
			 * @since 3.9
			 * @param  {Object} values - The values object.
			 * @return {String}
			 */
			getStyleVariables: function( values ) {
				var self = this,
					customVars = [],
					cssVarsOptions,
					labelColumnWidth,
					isRtl,
					columnGap,
					rowGap;

				// Heading typography.
				jQuery.each( _.fusionGetFontStyle( 'heading_font', values, 'object' ), function( rule, value ) {
						customVars[ 'heading-' + rule ] = value;
				} );

				// Text typography.
				jQuery.each( _.fusionGetFontStyle( 'text_font', values, 'object' ), function( rule, value ) {
						customVars[ 'text-' + rule ] = value;
				} );

				// Get spacing.
				jQuery.each( [ 'top', 'right', 'bottom', 'left' ], function( index, side ) {
					var cellPaddingName = 'cell_padding_' + side,
						marginName      = 'margin_' + side;


					// Add content padding to style.
					if ( '' !==  values[ cellPaddingName ] ) {
						customVars[ cellPaddingName ] =  _.fusionGetValueWithUnit( values[ cellPaddingName ] );
					}

					// Element margin.
					if ( '' !==  values[ marginName ] ) {
						customVars[ marginName ] = _.fusionGetValueWithUnit( values[ marginName ] );
					}
				} );

				// Only the keywords the option offers, as in the PHP. An empty value stays
				// unset so the CSS keeps following the reading direction.
				jQuery.each( [ 'label_text_align', 'value_text_align' ], function( index, align ) {
					if ( -1 !== jQuery.inArray( values[ align ], [ 'left', 'center', 'right' ] ) ) {
						customVars[ align ] = values[ align ];
					}
				} );

				// A swatch set is a flex container, so text alignment does not reach it; the
				// same choice goes over as a justify-content, flipped for RTL as in the PHP.
				if ( 'undefined' !== typeof customVars.value_text_align ) {
					isRtl = jQuery( 'body' ).hasClass( 'rtl' );

					customVars.value_justify = {
						left: isRtl ? 'flex-end' : 'flex-start',
						center: 'center',
						right: isRtl ? 'flex-start' : 'flex-end'
					}[ customVars.value_text_align ];
				}

				// Left unset when empty, so that the CSS can fall back to 30%, or to the icon's
				// own width when only icons are shown.
				labelColumnWidth = this.sanitizeColumnWidth( values.label_column_width );

				if ( '' !== labelColumnWidth ) {
					customVars.label_column_width = labelColumnWidth;
				}

				// The panel keys are the house column_gap / row_gap, but the variables stay
				// element scoped, as in the PHP: --awb-column-gap and --awb-row-gap are both
				// declared on .fusion-layout-column and would inherit in.
				columnGap = this.sanitizeLength( values.column_gap );

				if ( '' !== columnGap ) {
					customVars.label_column_gap = columnGap;
				}

				rowGap = this.sanitizeLength( values.row_gap );

				if ( '' !== rowGap ) {
					customVars.row_spacing = rowGap;
				}

				// Swatch styling, on the custom style only, as in the PHP.
				if ( 'swatch' === values.attribute_values && 'custom' === values.swatch_style ) {
					jQuery.each( this.getSwatchStyleOptions(), function( option, type ) {
						var value = 'undefined' === typeof values[ option ] ? '' : values[ option ];

						if ( '' === value ) {
							return;
						}

						value = 'size' === type ? self.sanitizeColumnWidth( value ) : ( 'color' === type ? value : self.sanitizeLength( value ) );

						if ( '' !== value ) {
							customVars[ option ] = value;
						}
					} );
				}

				cssVarsOptions = [
					'heading_color',
					'text_color',
					'border_color',
					'table_cell_backgroundcolor',
					'heading_cell_backgroundcolor',
					'heading_line_height',
					'heading_text_transform',
					'text_line_height',
					'text_text_transform'
				];

				cssVarsOptions.heading_font_size      = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.heading_font_size      = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.heading_letter_spacing = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.text_font_size         = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.text_letter_spacing    = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.border_size                      = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.table_border_radius_top_left     = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.table_border_radius_top_right    = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.table_border_radius_bottom_right = { 'callback': _.fusionGetValueWithUnit };
				cssVarsOptions.table_border_radius_bottom_left  = { 'callback': _.fusionGetValueWithUnit };


				return this.getCssVarsForOptions( cssVarsOptions ) + this.getCustomCssVars( customVars );
			},

			/**
			 * Sanitizes a column width, allowing a length or one of the sizing keywords.
			 *
			 * @since 3.16.1
			 * @param  {String} width - The width as entered.
			 * @return {String} The width to use, empty if it is not usable.
			 */
			sanitizeColumnWidth: function( width ) {
				width = 'undefined' === typeof width ? '' : jQuery.trim( String( width ) );

				if ( -1 !== jQuery.inArray( width, [ 'auto', 'fit-content', 'max-content', 'min-content' ] ) ) {
					return width;
				}

				return this.sanitizeLength( width );
			},

			/**
			 * Sanitizes a plain CSS length, so that the preview drops what the front end drops.
			 *
			 * @since 3.16.1
			 * @param  {String} length - The length as entered.
			 * @return {String} The length to use, empty if it is not usable.
			 */
			sanitizeLength: function( length ) {
				length = 'undefined' === typeof length ? '' : jQuery.trim( String( length ) );

				if ( ! /^-?\d*\.?\d+\s*[a-z%]*$/i.test( length ) ) {
					return '';
				}

				return _.fusionGetValueWithUnit( length );
			},

			/**
			 * The swatch styling options, and how each of them has to be sanitized.
			 *
			 * @since 3.16.1
			 * @return {Object} Option name to the sanitizing to apply.
			 */
			getSwatchStyleOptions: function() {
				var options = {
						swatch_background_color: 'color',
						swatch_border_color: 'color',
						button_swatch_color: 'color',
						button_swatch_font_size: 'length'
					},
					sides = [ 'top', 'right', 'bottom', 'left' ],
					corners = [ 'top_left', 'top_right', 'bottom_right', 'bottom_left' ];

				jQuery.each( [ 'swatch_margin', 'swatch_border_sizes' ], function( index, group ) {
					jQuery.each( sides, function( i, side ) {
						options[ group + '_' + side ] = 'length';
					} );
				} );

				jQuery.each( [ 'color', 'image', 'button' ], function( index, swatch ) {
					options[ swatch + '_swatch_width' ]  = 'size';
					options[ swatch + '_swatch_height' ] = 'size';

					jQuery.each( sides, function( i, side ) {
						options[ swatch + '_swatch_padding_' + side ] = 'length';
					} );

					jQuery.each( corners, function( i, corner ) {
						options[ swatch + '_swatch_border_radius_' + corner ] = 'length';
					} );
				} );

				return options;
			}
		} );
	} );
}( jQuery ) );
