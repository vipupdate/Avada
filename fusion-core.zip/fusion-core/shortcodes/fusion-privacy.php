<?php
/**
 * Avada-Builder Shortcode Element.
 *
 * @package Avada-Core
 * @since 3.5.2
 */

if ( function_exists( 'fusion_is_element_enabled' ) && fusion_is_element_enabled( 'fusion_privacy' ) && class_exists( 'Avada' ) && class_exists( 'FusionBuilder' ) ) {

	if ( ! class_exists( 'FusionSC_Privacy' ) && class_exists( 'Fusion_Element' ) ) {
		/**
		 * Shortcode class.
		 *
		 * @package fusion-core
		 * @since 3.5.2
		 */
		class FusionSC_Privacy extends Fusion_Element {

			/**
			 * Element counter, used for unique IDs.
			 *
			 * @since 3.5.2
			 * @var int
			 */
			private $privacy_counter = 0;

			/**
			 * Posted data if set.
			 *
			 * @since 3.5.2
			 * @var array
			 */
			private $data = false;

			/**
			 * Constructor.
			 *
			 * @access public
			 * @since 3.5.2
			 */
			public function __construct() {

				parent::__construct();

				add_action( 'template_redirect', [ $this, 'save_consents' ] );
				add_filter( 'fusion_attr_privacy-shortcode', [ $this, 'attr' ] );
				add_filter( 'fusion_attr_privacy-content', [ $this, 'content_attr' ] );
				add_filter( 'fusion_attr_privacy-form', [ $this, 'form_attr' ] );
				add_shortcode( 'fusion_privacy', [ $this, 'render' ] );
			}

			/**
			 * Gets the default values.
			 *
			 * @static
			 * @access public
			 * @since 2.0.0
			 * @return array
			 */
			public static function get_element_defaults() {

				$fusion_settings = awb_get_fusion_settings();

				return [
					'animation_direction'              => 'left',
					'animation_offset'                 => $fusion_settings->get( 'animation_offset' ),
					'animation_speed'                  => '',
					'animation_delay'                  => '',
					'animation_type'                   => '',
					'class'                            => '',
					'id'                               => '',
					'privacy_layout'                   => 'flat',
					'title_size'                       => 'h4',
					'form_field_layout'                => 'stacked',
					'consent_item_style'               => 'toggle',
					'hide_on_mobile'                   => fusion_builder_default_visibility( 'string' ),
					'show_wp_cookies'                  => '',
					'show_lifespan'                    => '',
					'show_description'                 => '',
					'show_description_toggle'          => '',
					'show_group_titles'                => 'yes',
					'show_group_description'           => 'no',
					'show_update_button'               => 'yes',
					'update_button_text'               => '',
					'show_accept_all_button'           => 'no',
					'accept_all_button_text'           => '',
					'show_reject_all_button'           => 'no',
					'reject_all_button_text'           => '',
					'save_action'                      => 'reload',
					'visible_groups'                   => implode( ',', array_keys( awb_get_privacy_content_names() ) ),
					'group_columns_layout'             => 'stacked',
					'group_columns_min_width'          => '',
					'group_columns_gap'                => '',
					'is_collapsible'                   => 'no',
					'collapsed_on_load'                => 'no',
					'show_group_toggle'                => '',

					// Design.
					'margin_top'                       => '',
					'margin_right'                     => '',
					'margin_bottom'                    => '',
					'margin_left'                      => '',
					'margin_top_medium'                => '',
					'margin_right_medium'              => '',
					'margin_bottom_medium'             => '',
					'margin_left_medium'               => '',
					'margin_top_small'                 => '',
					'margin_right_small'               => '',
					'margin_bottom_small'              => '',
					'margin_left_small'                => '',
					'padding_top'                      => '',
					'padding_right'                    => '',
					'padding_bottom'                   => '',
					'padding_left'                     => '',
					'padding_top_medium'               => '',
					'padding_right_medium'             => '',
					'padding_bottom_medium'            => '',
					'padding_left_medium'              => '',
					'padding_top_small'                => '',
					'padding_right_small'              => '',
					'padding_bottom_small'             => '',
					'padding_left_small'               => '',
					'fusion_font_family_title_font'    => '',
					'fusion_font_variant_title_font'   => '400',
					'title_font_size'                  => '',
					'title_color'                      => '',
					'title_line_height'                => '',
					'title_letter_spacing'             => '',
					'title_text_transform'             => '',
					'fusion_font_family_text_font'     => '',
					'fusion_font_variant_text_font'    => '400',
					'text_font_size'                   => '',
					'text_color'                       => '',
					'text_line_height'                 => '',
					'text_letter_spacing'              => '',
					'text_text_transform'              => '',
					'toggle_off_color'                 => '',
					'toggle_on_color'                  => '',
					'toggle_thumb_color'               => '',
					'necessary_opacity'                => $fusion_settings->get( 'privacy_necessary_opacity' ),
					'lifespan_color'                   => '',
					'desc_color'                       => '',
					'desc_font_size'                   => '',
					'buttons_alignment'                => 'flex-start',
				];
			}		

			/**
			 * Used to set any other variables for use on front-end editor template.
			 *
			 * @static
			 * @access public
			 * @since 2.0.0
			 * @return array
			 */
			public static function get_element_extras() {
				$embeds               = Avada()->privacy_embeds->get_embed_types();
				$labels               = [];
				$categories           = [];
				$descriptions         = [];
				$shared_embed_desc    = Avada()->settings->get( 'privacy_embed_description' );
				foreach ( $embeds as $id => $embed ) {
					$labels[ $id ]     = $embed['label'];
					$categories[ $id ] = isset( $embed['category'] ) ? $embed['category'] : 'embeds';
					$desc              = Avada()->settings->get( 'privacy_' . $id . '_description' );
					if ( empty( $desc ) ) {
						if ( 'embeds' === $categories[ $id ] && ! empty( $shared_embed_desc ) ) {
							$desc = $shared_embed_desc;
						} elseif ( ! empty( $embed['snippet_description'] ) ) {
							$desc = $embed['snippet_description'];
						}
					}
					$descriptions[ $id ] = $desc;
				}

				$privacy_expiry = (int) Avada()->settings->get( 'privacy_expiry' );

				return [
					'embed_type_ids'           => array_keys( $embeds ),
					'button_string'            => esc_attr__( 'Update', 'fusion-core' ),
					'accept_all_string'        => esc_attr__( 'Accept All', 'fusion-core' ),
					'reject_all_string'        => esc_attr__( 'Reject All', 'fusion-core' ),
					'wp_cookies'               => Avada()->privacy_embeds->get_default_wp_cookies(),
					'plugin_cookies'           => Avada()->privacy_embeds->get_plugin_necessary_cookies(),
					'custom_snippets'          => Avada()->privacy_embeds->get_custom_snippets(),
					'all_embed_labels'         => $labels,
					'all_embed_categories'     => $categories,
					'all_embed_descriptions'   => $descriptions,
					'privacy_bar_content'      => self::prepare_category_content_for_extras( Avada()->settings->get( 'privacy_bar_content' ) ),
					'privacy_expiry'           => $privacy_expiry,
					'show_lifespan_global'     => (bool) Avada()->settings->get( 'privacy_bar_show_lifespan' ),
					'show_desc_global'         => (bool) Avada()->settings->get( 'privacy_bar_show_cookie_desc' ),
					'show_desc_toggle_global'  => (bool) Avada()->settings->get( 'privacy_bar_desc_toggle' ),
					'show_group_toggle_global' => (bool) Avada()->settings->get( 'privacy_bar_show_group_toggle' ),
					'show_wp_cookies_global'   => (bool) Avada()->settings->get( 'privacy_bar_show_wp_cookies' ),
					'category_fallbacks'       => awb_get_privacy_content_names(),
				];
			}

			/**
			 * Prepares raw privacy_bar_content repeater data for extras: runs do_shortcode() on descriptions
			 * so the live editor initial load renders shortcodes.
			 *
			 * @static
			 * @access public
			 * @since 3.15.3
			 * @param  mixed $content Raw repeater option value.
			 * @return mixed
			 */
			public static function prepare_category_content_for_extras( $content ) {
				if ( is_array( $content ) && ! empty( $content['description'] ) && is_array( $content['description'] ) ) {
					$content['description'] = array_map( 'do_shortcode', $content['description'] );
				}
				return $content;
			}

			/**
			 * Maps settings to extra variables.
			 *
			 * @static
			 * @access public
			 * @since 2.0.0
			 * @return array
			 */
			public static function settings_to_extras() {
				return [
					'privacy_bar_show_lifespan'    => 'show_lifespan_global',
					'privacy_bar_show_cookie_desc' => 'show_desc_global',
					'privacy_bar_desc_toggle'        => 'show_desc_toggle_global',
					'privacy_bar_show_group_toggle'  => 'show_group_toggle_global',
					'privacy_bar_show_wp_cookies'    => 'show_wp_cookies_global',
					'privacy_expiry'               => 'privacy_expiry',
					'privacy_bar_content'          => 'privacy_bar_content',
					'custom_code_snippets'         => [
						'param'    => 'custom_snippets',
						'callback' => 'awbNormalizeRepeater',
					],
				];
			}

			/**
			 * Render the shortcode
			 *
			 * @access public
			 * @since 3.5.2
			 * @param  array  $args    Shortcode parameters.
			 * @param  string $content Content between shortcode.
			 * @return string          HTML output.
			 */
			public function render( $args, $content = '' ) {
				$defaults   = apply_filters( 'fusion_privacy_default_parameter', FusionBuilder::set_shortcode_defaults( self::get_element_defaults(), $args, 'fusion_privacy' ) );
				$content    = apply_filters( 'fusion_shortcode_content', $content, 'fusion_privacy', $args );
				$this->args = $defaults;

				$this->privacy_counter++;

				$html = '<div ' . FusionBuilder::attributes( 'privacy-shortcode' ) . '>';

				$html .= '<div ' . FusionBuilder::attributes( 'privacy-content' ) . '>' . wpautop( $content, false ) . '</div>';

				if ( class_exists( 'Avada_Privacy_Embeds' ) && Avada()->settings->get( 'privacy_embeds' ) ) {
					$html .= $this->privacy_embed_form();
				}

				$html .= '</div>';

				$this->on_render();

				return apply_filters( 'fusion_element_privacy_content', $html, $args );
			}

			/**
			 * Gets the HTML for the privacy embed form.
			 *
			 * @access public
			 * @since 3.5.2
			 * @return string
			 */
			public function privacy_embed_form() {
				$html = '';
				$html .= $this->get_alert();

				$embeds   = Avada()->privacy_embeds->get_embed_types();
				$snippets = Avada()->privacy_embeds->get_custom_snippets();

				if ( ! is_array( $embeds ) ) {
					return $html;
				}

				// Resolve effective display toggles.
				$privacy_expiry     = (int) Avada()->settings->get( 'privacy_expiry' );
				$show_lifespan      = $this->args['show_lifespan'];
				$show_desc          = $this->args['show_description'];
				$show_wp            = $this->args['show_wp_cookies'];
				$effective_lifespan = ( 'on' === $show_lifespan || ( '' === $show_lifespan && Avada()->settings->get( 'privacy_bar_show_lifespan' ) ) );
				$effective_desc     = ( 'on' === $show_desc || ( '' === $show_desc && Avada()->settings->get( 'privacy_bar_show_cookie_desc' ) ) );
				$show_desc_toggle   = $this->args['show_description_toggle'];
				$desc_toggle        = $effective_desc && ( 'on' === $show_desc_toggle || ( '' === $show_desc_toggle && Avada()->settings->get( 'privacy_bar_desc_toggle' ) ) );
				$effective_show_wp  = ( 'on' === $show_wp || ( '' === $show_wp && Avada()->settings->get( 'privacy_bar_show_wp_cookies' ) ) );
				$lifespan_str       = $effective_lifespan
					? sprintf( _n( '%s day', '%s days', $privacy_expiry, 'fusion-core' ), $privacy_expiry )
					: '';

				// Resolve visible groups (empty = show all).
				$visible_groups = ! empty( $this->args['visible_groups'] )
					? array_map( 'trim', explode( ',', $this->args['visible_groups'] ) )
					: [];

				$html .= '<form ' . FusionBuilder::attributes( 'privacy-form' ) . '>';

				$effective_show_group_titles = 'yes' === $this->args['show_group_titles'];
				$effective_show_group_desc   = 'yes' === $this->args['show_group_description'];
				$is_collapsible              = in_array( $this->args['is_collapsible'], [ 'collapsible', 'accordion' ], true ) && $effective_show_group_titles;
				$is_accordion                = 'accordion' === $this->args['is_collapsible'] && $effective_show_group_titles;
				$collapsed_on_load           = 'yes' === $this->args['collapsed_on_load'];
				$show_group_toggle_arg       = $this->args['show_group_toggle'];
				$show_group_toggle           = ( 'on' === $show_group_toggle_arg || ( '' === $show_group_toggle_arg && Avada()->settings->get( 'privacy_bar_show_group_toggle' ) ) ) && $effective_show_group_titles;

				if ( 'grouped' === $this->args['privacy_layout'] ) {
					$html .= $this->render_grouped( $embeds, $snippets, $visible_groups, $effective_lifespan, $effective_desc, $lifespan_str, $effective_show_wp, $effective_show_group_desc, $effective_show_group_titles, $is_collapsible, $collapsed_on_load, $show_group_toggle, $desc_toggle, $is_accordion );
				} else {
					$html .= $this->render_flat( $embeds, $effective_lifespan, $effective_desc, $lifespan_str, $effective_show_wp, $desc_toggle );
				}

				$html .= wp_referer_field( false );
				$html .= '<input type="hidden" name="privacyformid" value="' . $this->privacy_counter . '">';
				$html .= '<input type="hidden" name="consents[]" value="consent">';

				$show_update = 'yes' === $this->args['show_update_button'];
				$show_accept = 'yes' === $this->args['show_accept_all_button'];
				$show_reject = 'yes' === $this->args['show_reject_all_button'];

				if ( $show_update || $show_accept || $show_reject ) {
					$html .= '<div class="fusion-privacy-element-button-wrapper">';
					if ( $show_accept ) {
						$accept_text = ! empty( $this->args['accept_all_button_text'] ) ? $this->args['accept_all_button_text'] : esc_html__( 'Accept All', 'fusion-core' );
						$html .= '<button type="button" class="fusion-button fusion-button-default fusion-button-default-size fusion-privacy-element-accept-all">' . esc_html( $accept_text ) . '</button>';
					}
					if ( $show_reject ) {
						$reject_text = ! empty( $this->args['reject_all_button_text'] ) ? $this->args['reject_all_button_text'] : esc_html__( 'Reject All', 'fusion-core' );
						$html .= '<button type="button" class="fusion-button fusion-button-default fusion-button-default-size fusion-privacy-element-reject-all">' . esc_html( $reject_text ) . '</button>';
					}
					if ( $show_update ) {
						$update_text = ! empty( $this->args['update_button_text'] ) ? $this->args['update_button_text'] : esc_html__( 'Update', 'fusion-core' );
						$html .= '<button type="button" class="fusion-button fusion-button-default fusion-button-default-size fusion-privacy-element-update">' . esc_html( $update_text ) . '</button>';
					}
					$html .= '</div>';
				}

				$html .= wp_nonce_field( 'fusion_privacy_consents', 'fusion_privacy_nonce', true, false );
				$html .= '</form>';

				return $html;
			}

			/**
			 * Renders a single embed item `<li>`.
			 * 
			 * @access private
			 * @since 3.15.3
			 * @param string $id                 Embed type key.
			 * @param array  $embed              Embed type data.
			 * @param bool   $effective_lifespan Whether to show lifespan.
			 * @param bool   $effective_desc     Whether to show description.
			 * @param string $lifespan_str       Fallback lifespan string.
			 * @param bool   $disabled           Whether to render as disabled (necessary).
			 * @return string HTML.
			 */
			private function render_embed_item( $id, $embed, $effective_lifespan, $effective_desc, $lifespan_str, $disabled = false, $always_checked = false, $desc_toggle = false ) {
				$label     = isset( $embed['label'] ) ? $embed['label'] : $id;
				$label_opt = Avada()->settings->get( 'privacy_' . $id . '_label' );
				if ( $label_opt ) {
					$label = $label_opt;
				}

				$item_lifespan = '';
				if ( $effective_lifespan ) {
					$item_lifespan = ! empty( $embed['lifespan'] ) ? $embed['lifespan'] : $lifespan_str;
				}

				$item_desc = '';
				if ( $effective_desc ) {
					$item_desc = Avada()->privacy_embeds->get_embed_description( $id, $embed );
				}

				$selected_str = ( $always_checked || Avada()->privacy_embeds->is_selected( $id ) ) ? 'checked="checked" ' : '';
				$disabled_str = $disabled ? 'disabled="disabled" ' : '';
				$item_class   = $disabled ? ' class="is-necessary"' : '';

				$html  = '<li' . $item_class . '>';
				$html .= '<label for="privacy-embed-' . esc_attr( $id ) . '"' . ( $disabled ? ' style="pointer-events:none;"' : '' ) . '>';
				$html .= '<input name="consents[]" type="checkbox" value="' . esc_attr( $id ) . '" ' . $selected_str . $disabled_str . 'id="privacy-embed-' . esc_attr( $id ) . '">';
				$html .= '<span class="label-text">' . esc_html( $label );
				if ( $item_lifespan ) {
					$html .= '<span class="awb-cookie-lifespan">' . esc_html( $item_lifespan ) . '</span>';
				}
				$html .= '</span>';
				$html .= '</label>';
				if ( $item_desc && $desc_toggle ) {
					$html .= '<button type="button" class="awb-privacy-desc-toggle awb-rotate" aria-expanded="false" aria-label="' . esc_attr__( 'Toggle description', 'fusion-core' ) . '"><i class="awb-icon-angle-up"></i></button>';
				}
				if ( $item_desc ) {
					$html .= '<p class="awb-cookie-description">' . esc_html( $item_desc ) . '</p>';
				}
				$html .= '</li>';

				return $html;
			}

			/**
			 * Renders the flat layout — all selected embed types as a single list.
			 * 
			 * @access private
			 * @since 3.15.3
			 * @param array  $embeds             Active embed types.
			 * @param bool   $effective_lifespan Whether to show lifespan.
			 * @param bool   $effective_desc     Whether to show description.
			 * @param string $lifespan_str       Fallback lifespan string.
			 * @return string HTML.
			 */
			private function render_flat( $embeds, $effective_lifespan, $effective_desc, $lifespan_str, $effective_show_wp = false, $desc_toggle = false ) {
				$html = '<ul class="fusion-privacy-choices">';

				if ( $effective_show_wp ) {
					$all_necessary = array_merge(
						Avada()->privacy_embeds->get_default_wp_cookies(),
						Avada()->privacy_embeds->get_plugin_necessary_cookies()
					);
					foreach ( $all_necessary as $cookie_name => $cookie_data ) {
						$wp_embed = [
							'label'               => $cookie_name,
							'lifespan'            => isset( $cookie_data['lifespan'] ) ? $cookie_data['lifespan'] : '',
							'snippet_description' => isset( $cookie_data['description'] ) ? $cookie_data['description'] : '',
						];
						$html .= $this->render_embed_item( $cookie_name, $wp_embed, $effective_lifespan, $effective_desc, $lifespan_str, true, true, $desc_toggle );
					}
				}

				foreach ( $embeds as $id => $embed ) {
					$html .= $this->render_embed_item( $id, $embed, $effective_lifespan, $effective_desc, $lifespan_str, false, false, $desc_toggle );
				}
				$html .= '</ul>';
				return $html;
			}

			/**
			 * Renders the grouped layout — embed types grouped by category.
			 * 
			 * @access private
			 * @since 3.15.3
			 * @param array  $embeds             Active embed types.
			 * @param array  $snippets           Normalized custom code snippets.
			 * @param array  $visible_groups     Category keys to display (empty = all).
			 * @param bool   $effective_lifespan Whether to show lifespan.
			 * @param bool   $effective_desc     Whether to show description.
			 * @param string $lifespan_str       Fallback lifespan string.
			 * @param bool   $effective_show_wp  Whether to list individual WordPress cookies.
			 * @return string HTML.
			 */
			private function render_grouped( $embeds, $snippets, $visible_groups, $effective_lifespan, $effective_desc, $lifespan_str, $effective_show_wp = false, $effective_show_group_desc = false, $effective_show_group_titles = true, $is_collapsible = false, $collapsed_on_load = false, $show_group_toggle = false, $desc_toggle = false, $is_accordion = false ) {
				$html               = '';
				$title_tag          = esc_attr( $this->args['title_size'] );
				$category_fallbacks = awb_get_privacy_content_names();

				// Build key→title and key→description maps from the privacy bar content repeater.
				$bar_titles       = [];
				$bar_descriptions = [];
				foreach ( Avada()->privacy_embeds->get_privacy_content() as $column ) {
					$key = ! empty( $column['key'] ) ? $column['key'] : '';
					if ( $key ) {
						if ( ! empty( $column['title'] ) ) {
							$bar_titles[ $key ] = $column['title'];
						}
						if ( ! empty( $column['description'] ) ) {
							$bar_descriptions[ $key ] = $column['description'];
						}
					}
				}

				$category_order = $visible_groups;

				// Index embeds by category.
				$by_category = [];
				foreach ( $embeds as $id => $embed ) {
					$cat = isset( $embed['category'] ) ? $embed['category'] : 'embeds';
					$by_category[ $cat ][ $id ] = $embed;
				}

				// Necessary group always exists; also init any other repeater-defined
				// categories that have no embed items (e.g. custom ones).
				if ( ! isset( $by_category['necessary'] ) ) {
					$by_category['necessary'] = [];
				}
				foreach ( Avada()->privacy_embeds->get_privacy_content() as $column ) {
					$key = ! empty( $column['key'] ) ? $column['key'] : '';
					if ( $key && ! isset( $by_category[ $key ] ) ) {
						$by_category[ $key ] = [];
					}
				}

				$groups_class = 'fusion-privacy-groups';
				if ( 'columns' === $this->args['group_columns_layout'] ) {
					$groups_class .= ' fusion-privacy-groups--columns';
				}
				$html .= '<div class="' . esc_attr( $groups_class ) . '">';

				$is_first_group = true;
				foreach ( $category_order as $cat ) {
					if ( ! isset( $by_category[ $cat ] ) ) {
						continue;
					}

					$cat_label  = ! empty( $bar_titles[ $cat ] ) ? $bar_titles[ $cat ] : ( isset( $category_fallbacks[ $cat ] ) ? $category_fallbacks[ $cat ] : ucfirst( $cat ) );
					$is_collapsed = $collapsed_on_load || ( $is_accordion && ! $is_first_group );

					$html .= '<div class="fusion-privacy-group">';
					$cat_has_master = $show_group_toggle && 'necessary' !== $cat && ! empty( $by_category[ $cat ] );
					if ( ( $is_collapsible || $cat_has_master ) && $effective_show_group_titles ) {
						$html .= '<div class="fusion-privacy-group-heading">';
						$html .= '<' . $title_tag . ' class="fusion-privacy-group-title">' . esc_html( $cat_label ) . '</' . $title_tag . '>';
						if ( $cat_has_master ) {
							$html .= '<input type="checkbox" class="awb-privacy-group-master-input" data-category="' . esc_attr( $cat ) . '" aria-label="' . esc_attr__( 'Toggle all items in this group', 'fusion-core' ) . '">';
						}
						if ( $is_collapsible ) {
							$expanded   = $is_collapsed ? 'false' : 'true';
							$rotate_cls = $is_collapsed ? ' awb-rotate' : '';
							$html .= '<button type="button" class="awb-privacy-group-toggle' . $rotate_cls . '" aria-expanded="' . $expanded . '" aria-label="' . esc_attr__( 'Toggle group', 'fusion-core' ) . '"><i class="awb-icon-angle-up"></i></button>';
						}
						$html .= '</div>';
					} elseif ( $effective_show_group_titles ) {
						$html .= '<' . $title_tag . ' class="fusion-privacy-group-title">' . esc_html( $cat_label ) . '</' . $title_tag . '>';
					}
					if ( $is_collapsible ) {
						$html .= '<div class="fusion-privacy-group-body"' . ( $is_collapsed ? ' style="display:none;"' : '' ) . '>';
					}
					if ( $effective_show_group_desc && ! empty( $bar_descriptions[ $cat ] ) ) {
						$html .= '<div class="fusion-privacy-group-description">' . $bar_descriptions[ $cat ] . '</div>';
					}
					$has_items = 'necessary' === $cat || ! empty( $by_category[ $cat ] );
					if ( $has_items ) {
						$html .= '<ul class="fusion-privacy-choices">';

						if ( 'necessary' === $cat ) {
							// Individual WordPress and plugin necessary cookies (when enabled).
							if ( $effective_show_wp ) {
								$all_necessary = array_merge(
									Avada()->privacy_embeds->get_default_wp_cookies(),
									Avada()->privacy_embeds->get_plugin_necessary_cookies()
								);
								foreach ( $all_necessary as $cookie_name => $cookie_data ) {
									$wp_embed = [
										'label'               => $cookie_name,
										'lifespan'            => isset( $cookie_data['lifespan'] ) ? $cookie_data['lifespan'] : '',
										'snippet_description' => isset( $cookie_data['description'] ) ? $cookie_data['description'] : '',
									];
									$html .= $this->render_embed_item( $cookie_name, $wp_embed, $effective_lifespan, $effective_desc, $lifespan_str, true, true, $desc_toggle );
								}
							}

							// Necessary custom snippets.
							foreach ( $snippets as $snippet ) {
								if ( 'necessary' !== ( isset( $snippet['category'] ) ? $snippet['category'] : '' ) ) {
									continue;
								}
								$snip_key  = 'awb_snip_' . sanitize_title( $snippet['label'] );
								$snip_data = [
									'label'               => $snippet['label'],
									'lifespan'            => isset( $snippet['lifespan'] ) ? $snippet['lifespan'] : '',
									'snippet_description' => isset( $snippet['snippet_description'] ) ? $snippet['snippet_description'] : '',
								];
								$html .= $this->render_embed_item( $snip_key, $snip_data, $effective_lifespan, $effective_desc, $lifespan_str, true, false, $desc_toggle );
							}
						} else {
							// Embed items and snippets for this category — snippets are merged into
							// embed_types in set_embed_types_names(), so by_category covers both.
							foreach ( $by_category[ $cat ] as $id => $embed ) {
								$html .= $this->render_embed_item( $id, $embed, $effective_lifespan, $effective_desc, $lifespan_str, false, false, $desc_toggle );
							}
						}

						$html .= '</ul>';
					}
					if ( $is_collapsible ) {
						$html .= '</div>'; // .fusion-privacy-group-body
					}
					$html .= '</div>';
					$is_first_group = false;
				}

				$html .= '</div>'; // .fusion-privacy-groups

				return $html;
			}

			/**
			 * Fires on first render — enqueues the multi-instance merge script.
			 *
			 * @access protected
			 * @since 3.15.3
			 * @return void
			 */
			protected function on_first_render() {
				Fusion_Dynamic_JS::enqueue_script(
					'fusion-privacy',
					FusionCore_Plugin::$js_folder_url . '/fusion-privacy.js',
					FusionCore_Plugin::$js_folder_path . '/fusion-privacy.js',
					[ 'jquery' ],
					FUSION_CORE_VERSION,
					true
				);
			}

			/**
			 * Registers responsive CSS breakpoint files.
			 *
			 * @access public
			 * @since 3.15.3
			 * @return void
			 */
			public function add_css_files() {
				if ( ! defined( 'FUSION_BUILDER_VERSION' ) ) {
					return;
				}
				FusionBuilder()->add_element_css( FUSION_CORE_PATH . '/css/privacy.min.css' );
				Fusion_Media_Query_Scripts::$media_query_assets[] = [
					'awb-privacy-md',
					FUSION_BUILDER_PLUGIN_DIR . 'assets/css/media/privacy-md.min.css',
					[],
					FUSION_BUILDER_VERSION,
					Fusion_Media_Query_Scripts::get_media_query_from_key( 'fusion-max-medium' ),
				];
				Fusion_Media_Query_Scripts::$media_query_assets[] = [
					'awb-privacy-sm',
					FUSION_BUILDER_PLUGIN_DIR . 'assets/css/media/privacy-sm.min.css',
					[],
					FUSION_BUILDER_VERSION,
					Fusion_Media_Query_Scripts::get_media_query_from_key( 'fusion-max-small' ),
				];
			}

			/**
			 * Get the style variables.
			 *
			 * @access protected
			 * @since 3.15.3
			 * @return string
			 */
			protected function get_style_variables() {
				$css_vars_options = [
					'margin_top'              => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'margin_right'            => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'margin_bottom'           => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'margin_left'             => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'margin_top_medium'       => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'margin_right_medium'     => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'margin_bottom_medium'    => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'margin_left_medium'      => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'margin_top_small'        => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'margin_right_small'      => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'margin_bottom_small'     => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'margin_left_small'       => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'padding_top'             => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'padding_right'           => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'padding_bottom'          => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'padding_left'            => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'padding_top_medium'      => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'padding_right_medium'    => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'padding_bottom_medium'   => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'padding_left_medium'     => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'padding_top_small'       => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'padding_right_small'     => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'padding_bottom_small'    => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'padding_left_small'      => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'title_font_size'         => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'title_color',
					'title_line_height',
					'title_letter_spacing'    => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'title_text_transform',
					'text_font_size'          => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'text_color',
					'text_line_height',
					'text_letter_spacing'     => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'text_text_transform',
					'lifespan_color',
					'desc_color',
					'desc_font_size'          => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'group_columns_min_width' => [ 'callback' => [ 'Fusion_Sanitize', 'get_value_with_unit' ] ],
					'group_columns_gap',
					'buttons_alignment',
					'necessary_opacity',
					'toggle_on_color',
					'toggle_off_color',
					'toggle_thumb_color',
				];

				return $this->get_css_vars_for_options( $css_vars_options ) . $this->get_font_styling_vars( 'title_font' ) . $this->get_font_styling_vars( 'text_font' );
			}

			/**
			 * Builds the attributes array for the wrapper.
			 *
			 * @access public
			 * @since 3.5.2
			 * @return array
			 */
			public function attr() {

				$show_desc        = $this->args['show_description'];
				$effective_desc   = ( 'on' === $show_desc || ( '' === $show_desc && Avada()->settings->get( 'privacy_bar_show_cookie_desc' ) ) );
				$show_desc_toggle = $this->args['show_description_toggle'];
				$desc_toggle      = $effective_desc && ( 'on' === $show_desc_toggle || ( '' === $show_desc_toggle && Avada()->settings->get( 'privacy_bar_desc_toggle' ) ) );

				$attr = fusion_builder_visibility_atts(
					$this->args['hide_on_mobile'],
					[
						'class' => 'fusion-privacy-element fusion-privacy-element-' . $this->privacy_counter . ( $desc_toggle ? ' awb-desc-collapsed' : '' ) . ( 'accordion' === $this->args['is_collapsible'] ? ' fusion-privacy-accordion' : '' ),
						'style' => '',
					]
				);

				if ( $this->args['class'] ) {
					$attr['class'] .= ' ' . $this->args['class'];
				}

				if ( $this->args['id'] ) {
					$attr['id'] = $this->args['id'];
				}

				$attr['style'] .= $this->get_style_variables();

				// Animations.
				if ( $this->args['animation_type'] ) {
					$animations = FusionBuilder::animations(
						[
							'type'      => $this->args['animation_type'],
							'direction' => $this->args['animation_direction'],
							'speed'     => $this->args['animation_speed'],
							'offset'    => $this->args['animation_offset'],
							'delay'     => $this->args['animation_delay'],
						]
					);

					$attr = array_merge( $attr, $animations );

					$attr['class'] .= ' ' . $attr['animation_class'];
					unset( $attr['animation_class'] );

					if ( isset( $this->args['animation_color'] ) && $this->args['animation_color'] ) {
						$attr['style'] .= '--awb-animation-color:' . $this->args['animation_color'] . ';';
					}
				}

				return $attr;
			}

			/**
			 * Builds the attributes array for the content div.
			 *
			 * @access public
			 * @since 3.5.2
			 * @return array
			 */
			public function content_attr() {

				$attr = [
					'class' => 'fusion-privacy-form-intro',
				];

				return $attr;
			}

			/**
			 * Builds the attributes array for the form.
			 *
			 * @access public
			 * @since 3.5.2
			 * @return array
			 */
			public function form_attr() {
				$attr = [
					'id'               => 'fusion-privacy-form-' . $this->privacy_counter,
					'action'           => '',
					'method'           => 'post',
					'class'            => 'fusion-privacy-form fusion-privacy-form-' . $this->args['form_field_layout'] . ( 'toggle' === $this->args['consent_item_style'] ? ' fusion-privacy-form--toggle' : '' ),
					'data-save-action' => $this->args['save_action'],
				];

				return $attr;
			}

			/**
			 * Save the consents if submitted.
			 *
			 * @since 3.5.2
			 * @return void
			 */
			public function save_consents() {
				if ( ! isset( $_POST['fusion_privacy_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fusion_privacy_nonce'] ) ), 'fusion_privacy_consents' ) ) {
					return;
				}

				if ( isset( $_POST ) && isset( $_POST['privacyformid'] ) ) { // phpcs:ignore WordPress.Security

					$query_args = [
						'success' => 1,
						'id'      => (int) $_POST['privacyformid'], // phpcs:ignore WordPress.Security
					];

					if ( isset( $_POST['consents'] ) ) { // phpcs:ignore WordPress.Security
						Avada()->privacy_embeds->save_cookie( array_map( 'esc_attr', wp_unslash( $_POST['consents'] ) ) ); // phpcs:ignore WordPress.Security
					} else {
						Avada()->privacy_embeds->clear_cookie();
						$query_args['success'] = 2;
					}

					if ( isset( $_POST['_wp_http_referer'] ) ) { // phpcs:ignore WordPress.Security
						$redirection_link = wp_unslash( $_POST['_wp_http_referer'] ); // phpcs:ignore WordPress.Security
						$redirection_link = add_query_arg( $query_args, $redirection_link );
						wp_safe_redirect( $redirection_link );
					}
				}
			}

			/**
			 * Get the alert markup.
			 *
			 * @since 3.5.2
			 * @return string The alert.
			 */
			public function get_alert() {
				$alert = '';

				if ( isset( $_GET ) && isset( $_GET['success'] ) && isset( $_GET['id'] ) && $this->privacy_counter === (int) $_GET['id'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					if ( 1 === (int) $_GET['success'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
						if ( shortcode_exists( 'fusion_alert' ) ) {
							$alert = do_shortcode( '[fusion_alert type="success"]' . esc_html__( 'Your embed preferences have been updated.', 'fusion-core' ) . '[/fusion_alert]' );
						} else {
							$alert = '<h3 style="color:#468847;">' . esc_html__( 'Your embed preferences have been updated.', 'fusion-core' ) . '</h3>';
						}
					} else {
						if ( shortcode_exists( 'fusion_alert' ) ) {
							$alert = do_shortcode( '[fusion_alert type="success"]' . esc_html__( 'Your embed preferences have been cleared.', 'fusion-core' ) . '[/fusion_alert]' );
						} else {
							$alert = '<h3 style="color:#b94a48;">' . esc_html__( 'Your embed preferences have been cleared.', 'fusion-core' ) . '</h3>';
						}
					}
				}

				return $alert;
			}
		}
	}

	new FusionSC_Privacy();
}

function awb_get_privacy_content_names() {
	return $names = [
		'necessary'  => __( 'Necessary Cookies', 'fusion-core' ),
		'embeds'     => __( 'Functional Cookies', 'fusion-core' ),
		'statistics' => __( 'Statistics Cookies', 'fusion-core' ),
		'tracking'   => __( 'Marketing Cookies', 'fusion-core' ),
	];
}

/**
 * Map shortcode to Avada Builder.
 *
 * @since 3.5.2
 */
function fusion_element_privacy() {

	global $pagenow;
	$fusion_settings = awb_get_fusion_settings();
	if ( class_exists( 'Avada_Privacy_Embeds' ) && $fusion_settings->get( 'privacy_embeds' ) && function_exists( 'fusion_builder_map' ) && function_exists( 'fusion_builder_frontend_data' ) ) {

		// Build available category choices from the Consent Categories repeater — it defines
		// exactly which groups will render, so it's the sole source of truth here.
		$available_categories   = awb_get_privacy_content_names();
		$default_visible_groups = implode( ',', array_keys( $available_categories ) );

		foreach ( Avada()->privacy_embeds->get_privacy_content() as $column ) {
			$key = ! empty( $column['key'] ) ? $column['key'] : '';
			if ( $key && ! isset( $available_categories[ $key ] ) ) {
				$available_categories[ $key ] = esc_html( ! empty( $column['title'] ) ? $column['title'] : ucfirst( $key ) );
			}
		}

		fusion_builder_map(
			fusion_builder_frontend_data(
				'FusionSC_Privacy',
				[
					'name'            => __( 'Privacy & Consent', 'fusion-core' ),
					'shortcode'       => 'fusion_privacy',
					'icon'            => 'fusiona-privacy',
					'preview'         => FUSION_CORE_PATH . '/shortcodes/previews/fusion-privacy-preview.php',
					'preview_id'      => 'fusion-builder-block-module-privacy-preview-template',
					'front-end'       => FUSION_CORE_PATH . '/shortcodes/previews/front-end/fusion-privacy.php',
					'allow_generator' => true,
					'params'          => [
						// --- General Tab ---
						[
							'type'         => 'tinymce',
							'heading'      => esc_attr__( 'Privacy Text', 'fusion-core' ),
							'description'  => esc_attr__( 'Controls the privacy text which will show above the form.', 'fusion-core' ),
							'param_name'   => 'element_content',
							'value'        => esc_attr__( 'Your Content Goes Here', 'fusion-core' ),
							'placeholder'  => true,
							'dynamic_data' => true,
						],
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Cookie Grouping Layout', 'fusion-core' ),
							'description' => esc_attr__( 'Choose whether to display cookies in groups (by category) or as a flat list.', 'fusion-core' ),
							'param_name'  => 'privacy_layout',
							'value'       => [
								'flat'    => esc_attr__( 'Flat List', 'fusion-core' ),
								'grouped' => esc_attr__( 'Grouped', 'fusion-core' ),
							],
							'default'     => 'flat',
						],
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Group Display', 'fusion-core' ),
							'description' => esc_attr__( 'Choose whether groups are stacked vertically or arranged side by side in columns. In Columns mode, groups wrap automatically when they reach the minimum width.', 'fusion-core' ),
							'param_name'  => 'group_columns_layout',
							'value'       => [
								'stacked' => esc_attr__( 'Stacked', 'fusion-core' ),
								'columns' => esc_attr__( 'Columns', 'fusion-core' ),
							],
							'default'     => 'stacked',
							'dependency'  => [
								[
									'element'  => 'privacy_layout',
									'value'    => 'grouped',
									'operator' => '==',
								],
							],
						],
						[
							'type'        => 'range',
							'heading'     => esc_attr__( 'Column Minimum Width', 'fusion-core' ),
							'description' => esc_attr__( 'Minimum width of each column in pixels. Columns wrap to the next line automatically when they can no longer fit at this width.', 'fusion-core' ),
							'param_name'  => 'group_columns_min_width',
							'value'       => '',
							'min'         => '50',
							'max'         => '800',
							'step'        => '10',
							'default'     => '200',
							'dependency'  => [
								[
									'element'  => 'privacy_layout',
									'value'    => 'grouped',
									'operator' => '==',
								],
								[
									'element'  => 'group_columns_layout',
									'value'    => 'columns',
									'operator' => '==',
								],
							],
						],
						[
							'type'        => 'textfield',
							'heading'     => esc_attr__( 'Column Gap', 'fusion-core' ),
							'description' => esc_attr__( 'Gap between columns. Accepts any CSS value, e.g. 1em, 20px.', 'fusion-core' ),
							'param_name'  => 'group_columns_gap',
							'value'       => '1em',
							'dependency'  => [
								[
									'element'  => 'privacy_layout',
									'value'    => 'grouped',
									'operator' => '==',
								],
								[
									'element'  => 'group_columns_layout',
									'value'    => 'columns',
									'operator' => '==',
								],
							],
						],
						[
							'type'        => 'connected_sortable',
							'heading'     => esc_attr__( 'Visible Cookie Groups', 'fusion-core' ),
							'description' => esc_attr__( 'Choose which cookie groups to display and drag to reorder them. Groups on the left are active; drag to the right to hide.', 'fusion-core' ),
							'param_name'  => 'visible_groups',
							'choices'     => $available_categories,
							'default'     => $default_visible_groups,
							'dependency'  => [
								[
									'element'  => 'privacy_layout',
									'value'    => 'grouped',
									'operator' => '==',
								],
							],
						],
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Show Group Titles', 'fusion-core' ),
							'description' => esc_attr__( 'Whether to display the category title for each cookie group. Only applies to the Grouped layout.', 'fusion-core' ),
							'param_name'  => 'show_group_titles',
							'value'       => [
								'yes' => esc_attr__( 'Yes', 'fusion-core' ),
								'no'  => esc_attr__( 'No', 'fusion-core' ),
							],
							'default'     => 'yes',
							'dependency'  => [
								[
									'element'  => 'privacy_layout',
									'value'    => 'grouped',
									'operator' => '==',
								],
							],
						],						
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Collapsible Groups', 'fusion-core' ),
							'description' => esc_attr__( 'Collapsible adds a toggle to each group title. Accordion allows only one group open at a time.', 'fusion-core' ),
							'param_name'  => 'is_collapsible',
							'value'       => [
								'collapsible' => esc_attr__( 'Collapsible', 'fusion-core' ),
								'accordion'   => esc_attr__( 'Accordion', 'fusion-core' ),
								'no'          => esc_attr__( 'Off', 'fusion-core' ),
							],
							'default'     => 'no',
							'dependency'  => [
								[
									'element'  => 'privacy_layout',
									'value'    => 'grouped',
									'operator' => '==',
								],
								[
									'element'  => 'show_group_titles',
									'value'    => 'yes',
									'operator' => '==',
								],
							],
						],
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Collapsed on Load', 'fusion-core' ),
							'description' => esc_attr__( 'Whether groups start collapsed when the page loads.', 'fusion-core' ),
							'param_name'  => 'collapsed_on_load',
							'value'       => [
								'yes' => esc_attr__( 'Yes', 'fusion-core' ),
								'no'  => esc_attr__( 'No', 'fusion-core' ),
							],
							'default'     => 'no',
							'dependency'  => [
								[
									'element'  => 'privacy_layout',
									'value'    => 'grouped',
									'operator' => '==',
								],
								[
									'element'  => 'show_group_titles',
									'value'    => 'yes',
									'operator' => '==',
								],
								[
									'element'  => 'is_collapsible',
									'value'    => 'no',
									'operator' => '!=',
								],
							],
						],
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Group Master Toggle', 'fusion-core' ),
							'description' => esc_attr__( 'Display a master checkbox next to each group title to enable or disable all items in the group at once. The "Necessary" group is excluded. "Default" uses the Theme Option setting.', 'fusion-core' ),
							'param_name'  => 'show_group_toggle',
							'value'       => [
								''    => esc_attr__( 'Default', 'fusion-core' ),
								'on'  => esc_attr__( 'On', 'fusion-core' ),
								'off' => esc_attr__( 'Off', 'fusion-core' ),
							],
							'default'     => '',
							'dependency'  => [
								[
									'element'  => 'privacy_layout',
									'value'    => 'grouped',
									'operator' => '==',
								],
								[
									'element'  => 'show_group_titles',
									'value'    => 'yes',
									'operator' => '==',
								],
							],
						],
												[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Group Title HTML Tag', 'fusion-core' ),
							'description' => esc_attr__( 'Choose the HTML tag for the group title headings.', 'fusion-core' ),
							'param_name'  => 'title_size',
							'value'       => [
								'h1'  => 'H1',
								'h2'  => 'H2',
								'h3'  => 'H3',
								'h4'  => 'H4',
								'h5'  => 'H5',
								'h6'  => 'H6',
								'div' => 'DIV',
								'p'   => 'P',
							],
							'default'     => 'h4',
							'dependency'  => [
								[
									'element'  => 'privacy_layout',
									'value'    => 'grouped',
									'operator' => '==',
								],
								[
									'element'  => 'show_group_titles',
									'value'    => 'yes',
									'operator' => '==',
								],
							],
						],
						[

							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Consent Item Style', 'fusion-core' ),
							'description' => esc_attr__( 'Choose between standard checkboxes or slide toggles for the consent items and master toggles.', 'fusion-core' ),
							'param_name'  => 'consent_item_style',
							'value'       => [
								'checkbox' => esc_attr__( 'Checkbox', 'fusion-core' ),
								'toggle'   => esc_attr__( 'Toggle', 'fusion-core' ),
							],
							'default'     => 'toggle',
						],						
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Show Group Description', 'fusion-core' ),
							'description' => esc_attr__( 'Set to "yes" to display the category description set in the Consent Categories for each cookie group. Only applies to the Grouped layout.', 'fusion-core' ),
							'param_name'  => 'show_group_description',
							'value'       => [
								'yes' => esc_attr__( 'Yes', 'fusion-core' ),
								'no'  => esc_attr__( 'No', 'fusion-core' ),
							],
							'default'     => 'no',
							'dependency'  => [
								[
									'element'  => 'privacy_layout',
									'value'    => 'grouped',
									'operator' => '==',
								],
							],
						],
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Form Field Layout', 'fusion-core' ),
							'description' => esc_attr__( 'Choose if form checkboxes should be stacked and full width, or floated inline.', 'fusion-core' ),
							'param_name'  => 'form_field_layout',
							'value'       => [
								'stacked' => esc_attr__( 'Stacked', 'fusion-core' ),
								'floated' => esc_attr__( 'Floated', 'fusion-core' ),
							],
							'default'     => 'stacked',
						],
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'List WordPress Necessary Cookies', 'fusion-core' ),
							'description' => esc_attr__( 'Enable to automatically list standard WordPress necessary cookies in the Necessary group. If WooCommerce or The Events Calendar are active, their necessary cookies are included automatically. "Default" inherits from Global Options.', 'fusion-core' ),
							'param_name'  => 'show_wp_cookies',
							'value'       => [
								''    => esc_attr__( 'Default', 'fusion-core' ),
								'on'  => esc_attr__( 'On', 'fusion-core' ),
								'off' => esc_attr__( 'Off', 'fusion-core' ),
							],
							'default'     => '',
						],						
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Show Cookie Lifespan', 'fusion-core' ),
							'description' => esc_attr__( 'Whether to display the cookie lifespan next to each consent item.', 'fusion-core' ),
							'param_name'  => 'show_lifespan',
							'value'       => [
								''    => esc_attr__( 'Default', 'fusion-core' ),
								'on'  => esc_attr__( 'On', 'fusion-core' ),
								'off' => esc_attr__( 'Off', 'fusion-core' ),
							],
							'default'     => '',
						],
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Show Cookie Description', 'fusion-core' ),
							'description' => esc_attr__( 'Whether to display the cookie description for each consent item.', 'fusion-core' ),
							'param_name'  => 'show_description',
							'value'       => [
								''    => esc_attr__( 'Default', 'fusion-core' ),
								'on'  => esc_attr__( 'On', 'fusion-core' ),
								'off' => esc_attr__( 'Off', 'fusion-core' ),
							],
							'default'     => '',
						],
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Cookie Description Toggle', 'fusion-core' ),
							'description' => esc_attr__( 'Add a toggle button next to each consent item to expand/collapse its description. Descriptions start collapsed. "Default" uses the Theme Option setting.', 'fusion-core' ),
							'param_name'  => 'show_description_toggle',
							'value'       => [
								''    => esc_attr__( 'Default', 'fusion-core' ),
								'on'  => esc_attr__( 'On', 'fusion-core' ),
								'off' => esc_attr__( 'Off', 'fusion-core' ),
							],
							'default'     => '',
							'dependency'  => [
								[
									'element'  => 'show_description',
									'value'    => 'off',
									'operator' => '!=',
								],
							],
						],
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Show Update Button', 'fusion-core' ),
							'description' => esc_attr__( 'Choose whether to display the Update / Save consent button. When building a custom consent layout with multiple Privacy elements on one page (e.g. one per cookie group in separate columns or tabs), only one element needs to show this button — submitting it will automatically collect and merge choices from all instances.', 'fusion-core' ),
							'param_name'  => 'show_update_button',
							'value'       => [
								'yes' => esc_attr__( 'Yes', 'fusion-core' ),
								'no'  => esc_attr__( 'No', 'fusion-core' ),
							],
							'default'     => 'yes',
						],
						[
							'type'        => 'textfield',
							'heading'     => esc_attr__( 'Update Button Text', 'fusion-core' ),
							'description' => esc_attr__( 'Label for the Update button. Defaults to "Update" if left empty.', 'fusion-core' ),
							'param_name'  => 'update_button_text',
							'value'       => '',
							'placeholder' => true,
							'dependency'  => [
								[
									'element'  => 'show_update_button',
									'value'    => 'yes',
									'operator' => '==',
								],
							],
						],
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Show Accept All Button', 'fusion-core' ),
							'description' => esc_attr__( 'Choose whether to display an Accept All button that checks all optional items and saves.', 'fusion-core' ),
							'param_name'  => 'show_accept_all_button',
							'value'       => [
								'yes' => esc_attr__( 'Yes', 'fusion-core' ),
								'no'  => esc_attr__( 'No', 'fusion-core' ),
							],
							'default'     => 'no',
						],
						[
							'type'        => 'textfield',
							'heading'     => esc_attr__( 'Accept All Button Text', 'fusion-core' ),
							'description' => esc_attr__( 'Label for the Accept All button. Defaults to "Accept All" if left empty.', 'fusion-core' ),
							'param_name'  => 'accept_all_button_text',
							'value'       => '',
							'placeholder' => true,
							'dependency'  => [
								[
									'element'  => 'show_accept_all_button',
									'value'    => 'yes',
									'operator' => '==',
								],
							],
						],
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Show Reject All Button', 'fusion-core' ),
							'description' => esc_attr__( 'Choose whether to display a Reject All button that unchecks all optional items and saves.', 'fusion-core' ),
							'param_name'  => 'show_reject_all_button',
							'value'       => [
								'yes' => esc_attr__( 'Yes', 'fusion-core' ),
								'no'  => esc_attr__( 'No', 'fusion-core' ),
							],
							'default'     => 'no',
						],
						[
							'type'        => 'textfield',
							'heading'     => esc_attr__( 'Reject All Button Text', 'fusion-core' ),
							'description' => esc_attr__( 'Label for the Reject All button. Defaults to "Reject All" if left empty.', 'fusion-core' ),
							'param_name'  => 'reject_all_button_text',
							'value'       => '',
							'placeholder' => true,
							'dependency'  => [
								[
									'element'  => 'show_reject_all_button',
									'value'    => 'yes',
									'operator' => '==',
								],
							],
						],
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Save Action', 'fusion-core' ),
							'description' => esc_attr__( '"Reload Page" submits the form and reloads to re-render consent-gated content. "AJAX" saves client-side, replaces visible placeholders immediately, and fires an event (useful when the element is inside an Off Canvas).', 'fusion-core' ),
							'param_name'  => 'save_action',
							'value'       => [
								'reload' => esc_attr__( 'Reload Page', 'fusion-core' ),
								'ajax'   => esc_attr__( 'AJAX', 'fusion-core' ),
							],
							'default'     => 'reload',
						],
						[
							'type'        => 'checkbox_button_set',
							'heading'     => esc_attr__( 'Element Visibility', 'fusion-core' ),
							'param_name'  => 'hide_on_mobile',
							'value'       => fusion_builder_visibility_options( 'full' ),
							'default'     => fusion_builder_default_visibility( 'array' ),
							'description' => esc_attr__( 'Choose to show or hide the element on small, medium or large screens.', 'fusion-core' ),
						],
						[
							'type'        => 'textfield',
							'heading'     => esc_attr__( 'CSS Class', 'fusion-core' ),
							'description' => esc_attr__( 'Add a class to the wrapping HTML element.', 'fusion-core' ),
							'param_name'  => 'class',
							'value'       => '',
							'group'       => esc_attr__( 'General', 'fusion-core' ),
						],
						[
							'type'        => 'textfield',
							'heading'     => esc_attr__( 'CSS ID', 'fusion-core' ),
							'description' => esc_attr__( 'Add an ID to the wrapping HTML element.', 'fusion-core' ),
							'param_name'  => 'id',
							'value'       => '',
							'group'       => esc_attr__( 'General', 'fusion-core' ),
						],

						'fusion_margin_placeholder'            => [
							'param_name' => 'margin',
							'group'      => esc_attr__( 'Design', 'fusion-core' ),
							'value'      => [
								'margin_top'    => '',
								'margin_right'  => '',
								'margin_bottom' => '',
								'margin_left'   => '',
							],
							'responsive' => [
								'state'             => 'large',
								'additional_states' => [ 'medium', 'small' ],
							],
						],
						[
							'type'             => 'dimension',
							'remove_from_atts' => true,
							'heading'          => esc_attr__( 'Padding', 'fusion-core' ),
							'description'      => esc_attr__( 'Enter values including any CSS unit, ex: 20px, 2.5em.', 'fusion-core' ),
							'param_name'       => 'padding',
							'group'            => esc_attr__( 'Design', 'fusion-core' ),
							'value'            => [
								'padding_top'    => '',
								'padding_right'  => '',
								'padding_bottom' => '',
								'padding_left'   => '',
							],
							'responsive'       => [
								'state'             => 'large',
								'additional_states' => [ 'medium', 'small' ],
							],
						],
						[
							'type'             => 'typography',
							'heading'          => esc_attr__( 'Group Title Typography', 'fusion-core' ),
							'description'      => esc_attr__( 'Controls the typography of the cookie group titles.', 'fusion-core' ),
							'param_name'       => 'title_fonts',
							'choices'          => [
								'font-family'    => 'title_font',
								'font-size'      => 'title_font_size',
								'text-transform' => 'title_text_transform',
								'line-height'    => 'title_line_height',
								'letter-spacing' => 'title_letter_spacing',
								'color'          => 'title_color',
							],
							'default'          => [
								'font-family'    => '',
								'variant'        => '400',
								'text-transform' => '',
								'line-height'    => '',
								'letter-spacing' => '',
								'color'          => '',
							],
							'remove_from_atts' => true,
							'global'           => true,
							'group'            => esc_attr__( 'Design', 'fusion-core' ),
							'dependency'       => [
								[
									'element'  => 'privacy_layout',
									'value'    => 'grouped',
									'operator' => '==',
								],
								[
									'element'  => 'show_group_titles',
									'value'    => 'yes',
									'operator' => '==',
								],
							],
						],
						[
							'type'             => 'typography',
							'heading'          => esc_attr__( 'Main Text Typography', 'fusion-core' ),
							'description'      => esc_attr__( 'Controls the typography of the consent item labels and body text. Leave empty to inherit.', 'fusion-core' ),
							'param_name'       => 'text_fonts',
							'choices'          => [
								'font-family'    => 'text_font',
								'font-size'      => 'text_font_size',
								'text-transform' => 'text_text_transform',
								'line-height'    => 'text_line_height',
								'letter-spacing' => 'text_letter_spacing',
								'color'          => 'text_color',
							],
							'default'          => [
								'font-family'    => '',
								'variant'        => '400',
								'text-transform' => '',
								'line-height'    => '',
								'letter-spacing' => '',
								'color'          => '',
							],
							'remove_from_atts' => true,
							'global'           => true,
							'group'            => esc_attr__( 'Design', 'fusion-core' ),
						],
						[
							'type'        => 'colorpickeralpha',
							'heading'     => esc_attr__( 'Consent Item Toggle Inactive Color', 'fusion-core' ),
							'description' => esc_attr__( 'Track color when a consent item is disabled.', 'fusion-core' ),
							'param_name'  => 'toggle_off_color',
							'value'       => '',
							'default'     => 'var(--awb-color3)',
							'group'       => esc_attr__( 'Design', 'fusion-core' ),
							'dependency'  => [
								[
									'element'  => 'consent_item_style',
									'value'    => 'toggle',
									'operator' => '==',
								],
							],
						],						
						[
							'type'        => 'colorpickeralpha',
							'heading'     => esc_attr__( 'Consent Item Toggle Active Color', 'fusion-core' ),
							'description' => esc_attr__( 'Track color when a consent item is enabled.', 'fusion-core' ),
							'param_name'  => 'toggle_on_color',
							'value'       => '',
							'default'     => 'var(--awb-color5)',
							'group'       => esc_attr__( 'Design', 'fusion-core' ),
							'dependency'  => [
								[
									'element'  => 'consent_item_style',
									'value'    => 'toggle',
									'operator' => '==',
								],
							],
						],
						[
							'type'        => 'colorpickeralpha',
							'heading'     => esc_attr__( 'Consent Item Toggle Thumb Color', 'fusion-core' ),
							'description' => esc_attr__( 'Color of the consent item toggle thumb.', 'fusion-core' ),
							'param_name'  => 'toggle_thumb_color',
							'value'       => '',
							'default'     => 'var(--awb-color1)',
							'group'       => esc_attr__( 'Design', 'fusion-core' ),
							'dependency'  => [
								[
									'element'  => 'consent_item_style',
									'value'    => 'toggle',
									'operator' => '==',
								],
							],
						],
						[
							'type'        => 'range',
							'heading'     => esc_attr__( 'Necessary Cookies Opacity', 'fusion-core' ),
							'description' => esc_attr__( 'Controls the opacity of necessary cookie items. "Default" inherits from Global Options.', 'fusion-core' ),
							'param_name'  => 'necessary_opacity',
							'min'         => '0',
							'max'         => '1',
							'step'        => '0.1',
							'default'     => $fusion_settings->get( 'privacy_necessary_opacity' ),
							'value'       => '',
							'group'       => esc_attr__( 'Design', 'fusion-core' ),
							'dependency'  => [
								[
									'element'  => 'show_wp_cookies',
									'value'    => 'off',
									'operator' => '!=',
								],
							],
						],						
						[
							'type'        => 'colorpickeralpha',
							'heading'     => esc_attr__( 'Cookie Lifespan Color', 'fusion-core' ),
							'description' => esc_attr__( 'Controls the color of the cookie lifespan text.', 'fusion-core' ),
							'param_name'  => 'lifespan_color',
							'value'       => '',
							'default'     => '',
							'group'       => esc_attr__( 'Design', 'fusion-core' ),
							'dependency'  => [
								[
									'element'  => 'show_lifespan',
									'value'    => 'off',
									'operator' => '!=',
								],
							],
						],
						[
							'type'        => 'colorpickeralpha',
							'heading'     => esc_attr__( 'Cookie Description Color', 'fusion-core' ),
							'description' => esc_attr__( 'Controls the color of the cookie description text.', 'fusion-core' ),
							'param_name'  => 'desc_color',
							'value'       => '',
							'default'     => '',
							'group'       => esc_attr__( 'Design', 'fusion-core' ),
							'dependency'  => [
								[
									'element'  => 'show_description',
									'value'    => 'off',
									'operator' => '!=',
								],
							],
						],
						[
							'type'        => 'textfield',
							'heading'     => esc_attr__( 'Cookie Description Font Size', 'fusion-core' ),
							'description' => esc_attr__( 'Controls the font size of the cookie description. Enter value with unit, ex: 0.85em, 13px.', 'fusion-core' ),
							'param_name'  => 'desc_font_size',
							'value'       => '',
							'group'       => esc_attr__( 'Design', 'fusion-core' ),
							'dependency'  => [
								[
									'element'  => 'show_description',
									'value'    => 'off',
									'operator' => '!=',
								],
							],
						],
						[
							'type'        => 'radio_button_set',
							'heading'     => esc_attr__( 'Buttons Alignment', 'fusion-core' ),
							'description' => esc_attr__( 'Select the alignment of the buttons row.', 'fusion-core' ),
							'group'       => esc_attr__( 'Design', 'fusion-core' ),
							'param_name'  => 'buttons_alignment',
							'grid_layout' => true,
							'back_icons'  => true,
							'icons'       => [
								'flex-start'    => '<span class="fusiona-horizontal-flex-start"></span>',
								'center'        => '<span class="fusiona-horizontal-flex-center"></span>',
								'flex-end'      => '<span class="fusiona-horizontal-flex-end"></span>',
								'space-between' => '<span class="fusiona-horizontal-space-between"></span>',
								'space-around'  => '<span class="fusiona-horizontal-space-around"></span>',
								'space-evenly'  => '<span class="fusiona-horizontal-space-evenly"></span>',
							],
							'value'       => [
								'flex-start'    => esc_html__( 'Flex Start', 'fusion-core' ),
								'center'        => esc_html__( 'Center', 'fusion-core' ),
								'flex-end'      => esc_html__( 'Flex End', 'fusion-core' ),
								'space-between' => esc_html__( 'Space Between', 'fusion-core' ),
								'space-around'  => esc_html__( 'Space Around', 'fusion-core' ),
								'space-evenly'  => esc_html__( 'Space Evenly', 'fusion-core' ),
							],
							'default'     => 'flex-start',
						],						
						'fusion_conditional_render_placeholder' => [],
						'fusion_animation_placeholder'         => [
							'preview_selector' => '.fusion-privacy-element',
						],						
					],
				]
			)
		);
	}
}
add_action( 'fusion_builder_wp_loaded', 'fusion_element_privacy' );
