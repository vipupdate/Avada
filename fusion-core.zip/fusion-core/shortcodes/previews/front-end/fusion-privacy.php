<script type="text/html" id="tmpl-fusion_privacy-shortcode">
<div {{{ _.fusionGetAttributes( attr ) }}}>
<div {{{ _.fusionGetAttributes( contentAttr ) }}}> {{{ FusionPageBuilderApp.renderContent( output, cid, false ) }}} </div>
	<# if ( embeds && embeds.length ) { #>
		<form {{{ _.fusionGetAttributes( formAttr ) }}}>
			<# if ( 'grouped' === privacyLayout ) { #>
				<# var categoryOrder = visibleGroups ? visibleGroups.split( ',' ).map( function( s ) { return s.trim(); } ) : [ 'necessary', 'embeds', 'statistics', 'tracking' ]; #>
				<# var byCategory = { necessary: [] }; #>
				<# _.each( embeds, function( embed ) {
					var cat = embed.category || 'embeds';
					if ( ! byCategory[ cat ] ) { byCategory[ cat ] = []; }
					byCategory[ cat ].push( embed );
				} ); #>
				<# _.each( contentCategoryTypes, function( cat ) {
					if ( ! byCategory[ cat ] ) { byCategory[ cat ] = []; }
				} ); #>

				<# var groupsClass = 'fusion-privacy-groups' + ( 'columns' === groupColumnsLayout ? ' fusion-privacy-groups--columns' : '' ); #>
				<div class="{{ groupsClass }}">
				<# _.each( categoryOrder, function( cat ) {
					if ( ! byCategory[ cat ] ) {
						return;
					}
					var catLabel = ( groupTitles && groupTitles[ cat ] ) ? groupTitles[ cat ] : ( categoryFallbacks[ cat ] || cat );
				#>
					<div class="fusion-privacy-group">
						<# if ( showGroupTitles ) { #>
							<{{{ titleSize }}} class="fusion-privacy-group-title">{{ catLabel }}</{{{ titleSize }}}>
						<# } #>
						<# if ( showGroupDescription && groupDescriptions && groupDescriptions[ cat ] ) { #>
							<div class="fusion-privacy-group-description">{{{ groupDescriptions[ cat ] }}}</div>
						<# } #>
						<# var hasItems = 'necessary' === cat || byCategory[ cat ].length > 0; #>
						<# if ( hasItems ) { #>
						<ul class="fusion-privacy-choices">

							<# if ( 'necessary' === cat ) { #>
								<# if ( showWpCookies && wpCookies ) {
								_.each( wpCookies, function( cookieData, cookieName ) { #>
									<li class="is-necessary">
										<label style="pointer-events:none;">
											<input name="consents[]" type="checkbox" value="{{ cookieName }}" checked="checked" disabled="disabled">
											<span class="label-text">{{ cookieName }}
											<# if ( showLifespan && cookieData.lifespan ) { #>
												<span class="awb-cookie-lifespan">{{ cookieData.lifespan }}</span>
											<# } #>
											</span>
										</label>
										<# if ( showDesc && cookieData.description ) { #>
											<p class="awb-cookie-description">{{ cookieData.description }}</p>
										<# } #>
									</li>
								<# } ); } #>
								<# if ( showWpCookies && pluginCookies && ! _.isEmpty( pluginCookies ) ) {
								_.each( pluginCookies, function( cookieData, cookieName ) { #>
									<li class="is-necessary">
										<label style="pointer-events:none;">
											<input name="consents[]" type="checkbox" value="{{ cookieName }}" checked="checked" disabled="disabled">
											<span class="label-text">{{ cookieName }}
											<# if ( showLifespan && cookieData.lifespan ) { #>
												<span class="awb-cookie-lifespan">{{ cookieData.lifespan }}</span>
											<# } #>
											</span>
										</label>
										<# if ( showDesc && cookieData.description ) { #>
											<p class="awb-cookie-description">{{ cookieData.description }}</p>
										<# } #>
									</li>
								<# } ); } #>
								<# if ( customSnippets ) {
									_.each( customSnippets, function( snippet ) {
										if ( 'necessary' === snippet.category ) { #>
											<li class="is-necessary">
												<label style="pointer-events:none;">
													<input name="consents[]" type="checkbox" checked="checked" disabled="disabled">
													<span class="label-text">{{ snippet.label }}
													<# if ( showLifespan ) { #>
														<span class="awb-cookie-lifespan">{{ lifespanStr }}</span>
													<# } #>
													</span>
												</label>
												<# if ( showDesc && snippet.snippet_description ) { #>
													<p class="awb-cookie-description">{{ snippet.snippet_description }}</p>
												<# } #>
											</li>
									<# } } ); } #>
							<# } else { #>
								<# _.each( byCategory[ cat ], function( embed ) { #>
									<li>
										<label for="{{ embed.id }}-live">
											<input name="consents[]" type="checkbox" value="{{ embed.id }}" {{ embed.selected }} id="{{ embed.id }}-live">
											<span class="label-text">{{ embed.label }}
											<# if ( showLifespan ) { #>
												<span class="awb-cookie-lifespan"><# if ( embed.lifespan ) { #>{{ embed.lifespan }}<# } else { #>{{ lifespanStr }}<# } #></span>
											<# } #>
											</span>
										</label>
										<# if ( showDesc && embed.description ) { #>
											<p class="awb-cookie-description">{{ embed.description }}</p>
										<# } #>
									</li>
								<# } ); #>
							<# } #>

						</ul>
						<# } #>
					</div>
				<# } ); #>
				</div>

			<# } else { #>

				<ul class="fusion-privacy-choices">
					<# if ( showWpCookies && wpCookies ) {
					_.each( wpCookies, function( cookieData, cookieName ) { #>
						<li class="is-necessary">
							<label style="pointer-events:none;">
								<input name="consents[]" type="checkbox" value="{{ cookieName }}" checked="checked" disabled="disabled">
								<span class="label-text">{{ cookieName }}
								<# if ( showLifespan && cookieData.lifespan ) { #>
									<span class="awb-cookie-lifespan">{{ cookieData.lifespan }}</span>
								<# } #>
								</span>
							</label>
							<# if ( showDesc && cookieData.description ) { #>
								<p class="awb-cookie-description">{{ cookieData.description }}</p>
							<# } #>
						</li>
					<# } ); } #>
					<# if ( showWpCookies && pluginCookies && ! _.isEmpty( pluginCookies ) ) {
					_.each( pluginCookies, function( cookieData, cookieName ) { #>
						<li class="is-necessary">
							<label style="pointer-events:none;">
								<input name="consents[]" type="checkbox" value="{{ cookieName }}" checked="checked" disabled="disabled">
								<span class="label-text">{{ cookieName }}
								<# if ( showLifespan && cookieData.lifespan ) { #>
									<span class="awb-cookie-lifespan">{{ cookieData.lifespan }}</span>
								<# } #>
								</span>
							</label>
							<# if ( showDesc && cookieData.description ) { #>
								<p class="awb-cookie-description">{{ cookieData.description }}</p>
							<# } #>
						</li>
					<# } ); } #>
					<# _.each( embeds, function( embed ) { #>
						<li>
							<label for="{{ embed.id }}-live">
								<input name="consents[]" type="checkbox" value="{{ embed.id }}" {{ embed.selected }} id="{{ embed.id }}-live">
								<span class="label-text">{{ embed.label }}
								<# if ( showLifespan ) { #>
									<span class="awb-cookie-lifespan"><# if ( embed.lifespan ) { #>{{ embed.lifespan }}<# } else { #>{{ lifespanStr }}<# } #></span>
								<# } #>
								</span>
							</label>
							<# if ( showDesc && embed.description ) { #>
								<p class="awb-cookie-description">{{ embed.description }}</p>
							<# } #>
						</li>
					<# } ); #>
				</ul>

			<# } #>

			<# if ( showUpdateButton || showAcceptAllButton || showRejectAllButton ) { #>
				<div class="fusion-privacy-element-button-wrapper">
					<# if ( showAcceptAllButton ) { #>
						<button class="fusion-privacy-element-button fusion-privacy-element-accept-all fusion-button fusion-button-default fusion-button-default-size" type="button">{{ acceptAllButtonText }}</button>
					<# } #>
					<# if ( showRejectAllButton ) { #>
						<button class="fusion-privacy-element-button fusion-privacy-element-reject-all fusion-button fusion-button-default fusion-button-default-size" type="button">{{ rejectAllButtonText }}</button>
					<# } #>
					<# if ( showUpdateButton ) { #>
						<button class="fusion-privacy-element-button fusion-button fusion-button-default fusion-button-default-size" type="submit">{{ updateButtonText }}</button>
					<# } #>
				</div>
			<# } #>
		</form>
	<# } #>
</div>
</script>
